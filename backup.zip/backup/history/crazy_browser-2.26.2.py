import sys
from PyQt5.QtCore import QUrl
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QToolBar, QLineEdit, QPushButton,
    QStatusBar, QWidget, QVBoxLayout
)
from PyQt5.QtWebEngineWidgets import QWebEngineView


class CrazyBrowser(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("crazy_browser")
        self.setGeometry(100, 100, 1200, 800)

        # 创建浏览器视图
        self.browser = QWebEngineView()
        self.setCentralWidget(self.browser)

        # 首页 URL
        self.home_url = "https://search.oneapp.dev"

        # 创建导航工具栏
        self.create_nav_toolbar()

        # 创建状态栏
        self.status = QStatusBar()
        self.setStatusBar(self.status)

        # 加载首页
        self.load_home()

    def create_nav_toolbar(self):
        nav_bar = QToolBar("Navigation")
        self.addToolBar(nav_bar)

        # 后退按钮
        back_btn = QPushButton("←")
        back_btn.clicked.connect(self.browser.back)
        nav_bar.addWidget(back_btn)

        # 前进按钮
        forward_btn = QPushButton("→")
        forward_btn.clicked.connect(self.browser.forward)
        nav_bar.addWidget(forward_btn)

        # 刷新按钮
        reload_btn = QPushButton("↻")
        reload_btn.clicked.connect(self.browser.reload)
        nav_bar.addWidget(reload_btn)

        # 停止按钮
        stop_btn = QPushButton("✕")
        stop_btn.clicked.connect(self.browser.stop)
        nav_bar.addWidget(stop_btn)

        # 地址栏
        self.url_bar = QLineEdit()
        self.url_bar.returnPressed.connect(self.navigate_to_url)
        nav_bar.addWidget(self.url_bar)

        # 首页按钮
        home_btn = QPushButton("🏠")
        home_btn.clicked.connect(self.load_home)
        nav_bar.addWidget(home_btn)

        # 更新地址栏和状态栏
        self.browser.urlChanged.connect(self.update_url_bar)
        self.browser.loadProgress.connect(self.update_status)

    def navigate_to_url(self):
        """处理地址栏输入：若是 URL 则直接加载，否则使用 Bing 搜索"""
        text = self.url_bar.text().strip()
        if not text:
            return

        # 如果输入看起来像 URL（包含点或协议），直接加载
        if "." in text or text.startswith("chrome://") or text.startswith("http"):
            if not text.startswith("http") and not text.startswith("chrome://"):
                # 补全 http 协议
                text = "http://" + text
            url = QUrl.fromUserInput(text)
        else:
            # 否则使用 Bing 搜索
            search_url = f"https://www.bing.com/search?q={text}"
            url = QUrl(search_url)

        self.browser.setUrl(url)

    def load_home(self):
        self.browser.setUrl(QUrl(self.home_url))

    def update_url_bar(self, url):
        """当页面 URL 变化时更新地址栏"""
        self.url_bar.setText(url.toString())

    def update_status(self, progress):
        """更新加载进度到状态栏"""
        self.status.showMessage(f"Loading... {progress}%")

    def keyPressEvent(self, event):
        """可选：支持 F5 刷新等，这里忽略"""
        super().keyPressEvent(event)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = CrazyBrowser()
    window.show()
    sys.exit(app.exec_())