import sys
import json
import os
from datetime import datetime
from urllib.parse import urlparse, parse_qs
from PyQt5.QtCore import QUrl, Qt, QTimer
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QTabWidget, QToolBar, QLineEdit,
    QPushButton, QStatusBar, QVBoxLayout, QHBoxLayout,
    QMenu, QAction, QDialog, QListWidget, QListWidgetItem,
    QMessageBox, QComboBox, QDialogButtonBox, QFormLayout,
    QFileDialog, QWidget
)
from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEngineProfile, QWebEnginePage
from PyQt5.QtGui import QKeySequence


# -------------------- Constants --------------------
CONFIG_FILE = "crazy_browser_config.json"
BOOKMARKS_FILE = "crazy_browser_bookmarks.json"
HISTORY_FILE = "crazy_browser_history.json"
NEW_TAB_URL = "crazy-browser://newtab"
SETTINGS_URL = "crazy-browser://settings"

# -------------------- Data Manager --------------------
class DataManager:
    @staticmethod
    def load_json(file, default):
        try:
            with open(file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return default

    @staticmethod
    def save_json(file, data):
        with open(file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)


# -------------------- Translations --------------------
TRANSLATIONS = {
    "en": {
        "app_title": "crazy_browser",
        "home_label": "Home",
        "new_tab": "+ New Tab",
        "settings": "⚙ Settings",
        "placeholder": "Enter URL or search...",
        "back_tip": "Back",
        "forward_tip": "Forward",
        "reload_tip": "Reload",
        "home_tip": "Home",
        "bookmark_tip": "Add bookmark",
        "file_menu": "File",
        "new_tab_action": "New Tab (Ctrl+T)",
        "new_window_action": "New Window",
        "new_private_action": "New Private Window (Ctrl+Shift+N)",
        "close_tab_action": "Close Tab (Ctrl+W)",
        "history_menu": "History",
        "show_history": "Show All History",
        "clear_history": "Clear History",
        "bookmarks_menu": "Bookmarks",
        "add_bookmark": "Add Current Page",
        "manage_bookmarks": "Manage Bookmarks",
        "settings_menu": "Settings",
        "preferences": "Preferences",
        "developer_menu": "Developer",
        "dev_tools": "Developer Tools (F12)",
        "status_loading": "Loading {}%",
        "download_progress": "Downloading: {} {}%",
        "download_complete": "Download complete: {}",
        "bookmark_exists": "Already bookmarked.",
        "bookmark_added": "Added: {}",
        "no_bookmarks": "No bookmarks.",
        "manage_bookmarks_title": "Manage Bookmarks",
        "open": "Open",
        "delete": "Delete",
        "close": "Close",
        "no_history": "No history.",
        "history_title": "History",
        "history_cleared": "History cleared.",
        "settings_title": "Preferences",
        "home_page": "Home page:",
        "search_engine": "Search engine:",
        "language": "Language:",
        "ua_mode": "Device mode:",
        "theme": "Theme:",
        "light": "Light",
        "dark": "Dark",
        "desktop": "Desktop",
        "mobile": "Mobile",
        "save": "Save",
        "settings_saved": "Settings saved.",
        "confirm_clear_title": "Confirm Clear",
        "confirm_clear_msg": "Clear all cache, cookies and history?\nThis action cannot be undone.",
        "cleared_info_title": "Done",
        "cleared_info_msg": "Browser data cleared",
    },
    "zh": {
        "app_title": "疯狂浏览器",
        "home_label": "首页",
        "new_tab": "+ 新标签页",
        "settings": "⚙ 设置",
        "placeholder": "输入网址或搜索内容...",
        "back_tip": "后退",
        "forward_tip": "前进",
        "reload_tip": "刷新",
        "home_tip": "主页",
        "bookmark_tip": "添加书签",
        "file_menu": "文件",
        "new_tab_action": "新建标签页 (Ctrl+T)",
        "new_window_action": "新建窗口",
        "new_private_action": "新建无痕窗口 (Ctrl+Shift+N)",
        "close_tab_action": "关闭标签页 (Ctrl+W)",
        "history_menu": "历史",
        "show_history": "显示全部历史",
        "clear_history": "清除历史记录",
        "bookmarks_menu": "书签",
        "add_bookmark": "添加当前页面",
        "manage_bookmarks": "管理书签",
        "settings_menu": "设置",
        "preferences": "偏好设置",
        "developer_menu": "开发者",
        "dev_tools": "开发者工具 (F12)",
        "status_loading": "加载中 {}%",
        "download_progress": "下载中: {} {}%",
        "download_complete": "下载完成: {}",
        "bookmark_exists": "已存在于书签中。",
        "bookmark_added": "已添加: {}",
        "no_bookmarks": "暂无书签。",
        "manage_bookmarks_title": "管理书签",
        "open": "打开",
        "delete": "删除",
        "close": "关闭",
        "no_history": "暂无历史记录。",
        "history_title": "历史记录",
        "history_cleared": "历史记录已清除。",
        "settings_title": "偏好设置",
        "home_page": "首页地址:",
        "search_engine": "搜索引擎:",
        "language": "语言:",
        "ua_mode": "设备模式:",
        "theme": "主题:",
        "light": "浅色",
        "dark": "深色",
        "desktop": "桌面",
        "mobile": "手机",
        "save": "保存",
        "settings_saved": "设置已保存。",
        "confirm_clear_title": "确认清除",
        "confirm_clear_msg": "确定要清除所有缓存、Cookie和历史记录吗？\n此操作不可撤销。",
        "cleared_info_title": "操作完成",
        "cleared_info_msg": "浏览器数据已清除",
    }
}


# -------------------- Custom Web Page (with internal page handling) --------------------
class CrazyWebPage(QWebEnginePage):
    def __init__(self, view, is_private=False):
        super().__init__(view)
        self.view = view

    def acceptNavigationRequest(self, url, nav_type, is_main_frame):
        if not is_main_frame:
            return True

        # Handle internal pages
        if url.scheme() == "crazy-browser":
            path = url.path()
            if path == "/newtab":
                self.view.load_new_tab_page()
                return False
            elif path == "/settings":
                # If there are query params, save settings and reload without params
                query = url.query()
                if query:
                    params = parse_qs(query)
                    main = self.view.get_main_window()
                    if main:
                        # Update config
                        if "language" in params:
                            main.language = params["language"][0]
                        if "home_url" in params:
                            main.config["home_url"] = params["home_url"][0]
                        if "search_engine" in params:
                            main.config["search_engine"] = params["search_engine"][0]
                        if "ua_mode" in params:
                            main.ua_mode = params["ua_mode"][0]
                        if "theme" in params:
                            main.theme = params["theme"][0]
                        main.save_all_settings()
                        # Apply changes
                        main.apply_theme(main.theme)
                        main.apply_ua()
                        main.update_ui_texts()
                        # Reload settings page (no params)
                        QTimer.singleShot(100, lambda: self.view.load_settings_page())
                        return False
                else:
                    # Load settings page
                    self.view.load_settings_page()
                    return False
            else:
                # Unknown internal page, show blank
                self.view.setHtml("<h1>404 - Page not found</h1>")
                return False
        return True


# -------------------- Custom Web View --------------------
class CrazyWebView(QWebEngineView):
    def __init__(self, parent=None, is_private=False):
        super().__init__(parent)
        self.is_private = is_private
        self.download_progress = 0

        # Use custom page
        page = CrazyWebPage(self, is_private)
        self.setPage(page)

        # Private browsing profile
        if is_private:
            self.page().profile().setPersistentStoragePolicy(
                QWebEngineProfile.MemoryStorage
            )
            self.page().profile().setPersistentCookiesPolicy(
                QWebEngineProfile.NoPersistentCookies
            )

        # Download handler
        self.page().profile().downloadRequested.connect(self.handle_download)

        # Context menu with DevTools
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.open_context_menu)

    def get_main_window(self):
        """Traverse up to find the main CrazyBrowser instance."""
        p = self.parent()
        while p:
            if isinstance(p, CrazyBrowser):
                return p
            p = p.parent()
        return None

    def createWindow(self, window_type):
        """Open target="_blank" links in a new tab."""
        main = self.get_main_window()
        if main:
            new_view = CrazyWebView(parent=None, is_private=self.is_private)
            index = main.tab_widget.addTab(new_view, "New Tab")
            main.tab_widget.setCurrentIndex(index)
            new_view.titleChanged.connect(lambda t: main.update_tab_title(new_view, t))
            new_view.urlChanged.connect(lambda qurl: main.update_url_bar(qurl, new_view))
            new_view.loadProgress.connect(lambda p: main.update_status(p, new_view))
            new_view.loadFinished.connect(lambda ok: main.record_history_if_needed(new_view))
            return new_view
        return super().createWindow(window_type)

    def load_new_tab_page(self):
        """Load the custom new tab page with a search box."""
        main = self.get_main_window()
        if not main:
            return
        search_engine = main.config.get("search_engine", "https://www.bing.com/search?q={}")
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>New Tab</title>
            <style>
                body {{
                    margin: 0;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    background: #1a1a1a;
                    font-family: Arial, sans-serif;
                }}
                .container {{
                    text-align: center;
                    padding: 40px;
                    background: #2d2d2d;
                    border-radius: 20px;
                    box-shadow: 0 10px 40px rgba(0,0,0,0.6);
                }}
                h1 {{
                    color: #ffffff;
                    font-size: 36px;
                    margin-bottom: 30px;
                }}
                .search-box {{
                    display: flex;
                    justify-content: center;
                    gap: 10px;
                }}
                #search-input {{
                    width: 400px;
                    padding: 14px 20px;
                    font-size: 18px;
                    border: none;
                    border-radius: 30px;
                    outline: none;
                    background: #3d3d3d;
                    color: #ffffff;
                }}
                #search-btn {{
                    padding: 14px 28px;
                    font-size: 18px;
                    border: none;
                    border-radius: 30px;
                    background: #4a90d9;
                    color: #fff;
                    cursor: pointer;
                    transition: background 0.2s;
                }}
                #search-btn:hover {{
                    background: #5a9ef0;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>🌐 crazy_browser</h1>
                <div class="search-box">
                    <input id="search-input" type="text" placeholder="Search or enter address..." autofocus>
                    <button id="search-btn">Search</button>
                </div>
            </div>
            <script>
                const input = document.getElementById('search-input');
                const btn = document.getElementById('search-btn');
                function doSearch() {{
                    const q = input.value.trim();
                    if (!q) return;
                    const engine = '{search_engine}';
                    const url = engine.replace('{{}}', encodeURIComponent(q));
                    window.location.href = url;
                }}
                btn.addEventListener('click', doSearch);
                input.addEventListener('keydown', (e) => {{
                    if (e.key === 'Enter') doSearch();
                }});
            </script>
        </body>
        </html>
        """
        self.setHtml(html, baseUrl=QUrl(NEW_TAB_URL))

    def load_settings_page(self):
        """Load the settings page with current configuration."""
        main = self.get_main_window()
        if not main:
            return
        t = main.translations[main.language]
        config = main.config
        current_lang = main.language
        current_theme = main.theme
        current_ua = main.ua_mode
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>{t['settings_title']}</title>
            <style>
                body {{
                    font-family: Arial, sans-serif;
                    background: #f0f0f0;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    margin: 0;
                }}
                .settings-container {{
                    background: white;
                    padding: 40px;
                    border-radius: 20px;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                    width: 450px;
                }}
                h1 {{
                    text-align: center;
                    color: #333;
                }}
                .form-group {{
                    margin-bottom: 18px;
                }}
                label {{
                    display: block;
                    font-weight: bold;
                    margin-bottom: 5px;
                    color: #555;
                }}
                input[type="text"], select {{
                    width: 100%;
                    padding: 10px;
                    border: 1px solid #ccc;
                    border-radius: 8px;
                    font-size: 14px;
                    box-sizing: border-box;
                }}
                .radio-group {{
                    display: flex;
                    gap: 20px;
                    margin-top: 6px;
                }}
                .radio-group label {{
                    font-weight: normal;
                }}
                .btn-save {{
                    width: 100%;
                    padding: 12px;
                    background: #4a90d9;
                    color: white;
                    border: none;
                    border-radius: 8px;
                    font-size: 16px;
                    cursor: pointer;
                    margin-top: 10px;
                }}
                .btn-save:hover {{
                    background: #5a9ef0;
                }}
            </style>
        </head>
        <body>
            <div class="settings-container">
                <h1>{t['settings_title']}</h1>
                <form id="settings-form" action="{SETTINGS_URL}" method="get">
                    <div class="form-group">
                        <label for="language">{t['language']}</label>
                        <select id="language" name="language">
                            <option value="en" {'selected' if current_lang=='en' else ''}>English</option>
                            <option value="zh" {'selected' if current_lang=='zh' else ''}>中文</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="home_url">{t['home_page']}</label>
                        <input type="text" id="home_url" name="home_url" value="{config['home_url']}">
                    </div>
                    <div class="form-group">
                        <label for="search_engine">{t['search_engine']}</label>
                        <select id="search_engine" name="search_engine">
                            <option value="https://www.bing.com/search?q={{}}" {'selected' if config['search_engine']=='https://www.bing.com/search?q={{}}' else ''}>Bing</option>
                            <option value="https://www.google.com/search?q={{}}" {'selected' if config['search_engine']=='https://www.google.com/search?q={{}}' else ''}>Google</option>
                            <option value="https://duckduckgo.com/?q={{}}" {'selected' if config['search_engine']=='https://duckduckgo.com/?q={{}}' else ''}>DuckDuckGo</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>{t['ua_mode']}</label>
                        <div class="radio-group">
                            <label><input type="radio" name="ua_mode" value="desktop" {'checked' if current_ua=='desktop' else ''}> {t['desktop']}</label>
                            <label><input type="radio" name="ua_mode" value="mobile" {'checked' if current_ua=='mobile' else ''}> {t['mobile']}</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>{t['theme']}</label>
                        <div class="radio-group">
                            <label><input type="radio" name="theme" value="light" {'checked' if current_theme=='light' else ''}> {t['light']}</label>
                            <label><input type="radio" name="theme" value="dark" {'checked' if current_theme=='dark' else ''}> {t['dark']}</label>
                        </div>
                    </div>
                    <button type="submit" class="btn-save">{t['save']}</button>
                </form>
            </div>
        </body>
        </html>
        """
        self.setHtml(html, baseUrl=QUrl(SETTINGS_URL))

    def handle_download(self, download):
        """Save downloaded file."""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Save File", download.suggestedFileName()
        )
        if file_path:
            download.setPath(file_path)
            download.accept()
            download.downloadProgress.connect(
                lambda r, t: self.parent().parent().statusBar().showMessage(
                    self.get_main_window().translations[self.get_main_window().language]["download_progress"].format(
                        download.suggestedFileName(), int(r/t*100)
                    )
                ) if self.parent() else None
            )
            download.finished.connect(
                lambda: self.parent().parent().statusBar().showMessage(
                    self.get_main_window().translations[self.get_main_window().language]["download_complete"].format(
                        os.path.basename(file_path)
                    )
                ) if self.parent() else None
            )

    def open_context_menu(self, pos):
        menu = self.page().createStandardContextMenu()
        dev_action = QAction("Developer Tools (F12)", self)
        dev_action.triggered.connect(lambda: self.page().triggerAction(
            QWebEnginePage.InspectElement
        ))
        menu.addSeparator()
        menu.addAction(dev_action)
        menu.exec_(self.mapToGlobal(pos))


# -------------------- Main Browser Window --------------------
class CrazyBrowser(QMainWindow):
    def __init__(self, is_private=False, parent=None):
        super().__init__(parent)
        self.is_private = is_private

        # Load config
        self.config = DataManager.load_json(CONFIG_FILE, {
            "home_url": "https://creativesearch.pages.dev",
            "search_engine": "https://www.bing.com/search?q={}"
        })
        # Load extra settings
        extra = DataManager.load_json(CONFIG_FILE, {})
        self.language = extra.get("language", "en")
        self.theme = extra.get("theme", "light")
        self.ua_mode = extra.get("ua_mode", "desktop")

        self.translations = TRANSLATIONS
        self.bookmarks = DataManager.load_json(BOOKMARKS_FILE, [])
        self.history_data = DataManager.load_json(HISTORY_FILE, [])

        # Window setup
        self.setGeometry(100, 100, 1200, 800)
        self.setWindowTitle(self.translations[self.language]["app_title"])

        # Tab widget
        self.tab_widget = QTabWidget()
        self.tab_widget.setTabsClosable(True)
        self.tab_widget.tabCloseRequested.connect(self.close_tab)
        self.tab_widget.currentChanged.connect(self.on_tab_changed)
        self.setCentralWidget(self.tab_widget)

        # Toolbars and menus
        self.create_toolbar()
        self.create_menu_bar()

        # Status bar
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)

        # Apply theme and UA
        self.apply_theme(self.theme)
        self.apply_ua()

        # Initial tab: load home page
        self.new_tab(self.config["home_url"], self.translations[self.language]["home_label"])

        # Keyboard shortcuts
        self.setup_shortcuts()

    def create_toolbar(self):
        nav_bar = QToolBar("Navigation")
        self.addToolBar(nav_bar)

        # Back
        self.back_btn = QPushButton("←")
        self.back_btn.clicked.connect(lambda: self.current_view().back())
        self.back_btn.setToolTip(self.translations[self.language]["back_tip"])
        nav_bar.addWidget(self.back_btn)

        # Forward
        self.forward_btn = QPushButton("→")
        self.forward_btn.clicked.connect(lambda: self.current_view().forward())
        self.forward_btn.setToolTip(self.translations[self.language]["forward_tip"])
        nav_bar.addWidget(self.forward_btn)

        # Reload
        self.reload_btn = QPushButton("↻")
        self.reload_btn.clicked.connect(lambda: self.current_view().reload())
        self.reload_btn.setToolTip(self.translations[self.language]["reload_tip"])
        nav_bar.addWidget(self.reload_btn)

        # Stop
        self.stop_btn = QPushButton("✕")
        self.stop_btn.clicked.connect(lambda: self.current_view().stop())
        nav_bar.addWidget(self.stop_btn)

        # URL bar
        self.url_bar = QLineEdit()
        self.url_bar.returnPressed.connect(self.navigate_to_url)
        self.url_bar.setPlaceholderText(self.translations[self.language]["placeholder"])
        nav_bar.addWidget(self.url_bar)

        # Home
        self.home_btn = QPushButton("🏠")
        self.home_btn.clicked.connect(self.go_home)
        self.home_btn.setToolTip(self.translations[self.language]["home_tip"])
        nav_bar.addWidget(self.home_btn)

        # New tab
        self.new_tab_btn = QPushButton("+")
        self.new_tab_btn.clicked.connect(lambda: self.new_tab(None))
        nav_bar.addWidget(self.new_tab_btn)

        # Bookmark
        self.bookmark_btn = QPushButton("☆")
        self.bookmark_btn.clicked.connect(self.add_current_bookmark)
        self.bookmark_btn.setToolTip(self.translations[self.language]["bookmark_tip"])
        nav_bar.addWidget(self.bookmark_btn)

        # Settings button (opens internal settings page)
        self.settings_btn = QPushButton("⚙")
        self.settings_btn.clicked.connect(self.open_settings_page)
        self.settings_btn.setToolTip(self.translations[self.language]["settings"])
        nav_bar.addWidget(self.settings_btn)

    def create_menu_bar(self):
        menubar = self.menuBar()

        # File menu
        self.file_menu = menubar.addMenu(self.translations[self.language]["file_menu"])
        self.new_tab_action = QAction(self.translations[self.language]["new_tab_action"], self)
        self.new_tab_action.triggered.connect(lambda: self.new_tab(None))
        self.file_menu.addAction(self.new_tab_action)

        self.new_window_action = QAction(self.translations[self.language]["new_window_action"], self)
        self.new_window_action.triggered.connect(self.new_window)
        self.file_menu.addAction(self.new_window_action)

        self.new_private_action = QAction(self.translations[self.language]["new_private_action"], self)
        self.new_private_action.triggered.connect(self.new_private_window)
        self.file_menu.addAction(self.new_private_action)

        self.file_menu.addSeparator()
        self.close_tab_action = QAction(self.translations[self.language]["close_tab_action"], self)
        self.close_tab_action.triggered.connect(lambda: self.close_tab(self.tab_widget.currentIndex()))
        self.file_menu.addAction(self.close_tab_action)

        # History menu
        self.history_menu = menubar.addMenu(self.translations[self.language]["history_menu"])
        self.show_history_action = QAction(self.translations[self.language]["show_history"], self)
        self.show_history_action.triggered.connect(self.show_history_dialog)
        self.history_menu.addAction(self.show_history_action)

        self.clear_history_action = QAction(self.translations[self.language]["clear_history"], self)
        self.clear_history_action.triggered.connect(self.clear_history)
        self.history_menu.addAction(self.clear_history_action)

        # Bookmarks menu
        self.bookmarks_menu = menubar.addMenu(self.translations[self.language]["bookmarks_menu"])
        self.add_bookmark_action = QAction(self.translations[self.language]["add_bookmark"], self)
        self.add_bookmark_action.triggered.connect(self.add_current_bookmark)
        self.bookmarks_menu.addAction(self.add_bookmark_action)

        self.manage_bookmarks_action = QAction(self.translations[self.language]["manage_bookmarks"], self)
        self.manage_bookmarks_action.triggered.connect(self.show_bookmarks_dialog)
        self.bookmarks_menu.addAction(self.manage_bookmarks_action)

        # Settings menu
        self.settings_menu = menubar.addMenu(self.translations[self.language]["settings_menu"])
        self.preferences_action = QAction(self.translations[self.language]["preferences"], self)
        self.preferences_action.triggered.connect(self.open_settings_page)
        self.settings_menu.addAction(self.preferences_action)

        # Developer menu
        self.dev_menu = menubar.addMenu(self.translations[self.language]["developer_menu"])
        self.dev_tools_action = QAction(self.translations[self.language]["dev_tools"], self)
        self.dev_tools_action.triggered.connect(lambda: self.current_view().page().triggerAction(
            QWebEnginePage.InspectElement
        ))
        self.dev_menu.addAction(self.dev_tools_action)

    def setup_shortcuts(self):
        new_tab_shortcut = QAction(self)
        new_tab_shortcut.setShortcut(QKeySequence("Ctrl+T"))
        new_tab_shortcut.triggered.connect(lambda: self.new_tab(None))
        self.addAction(new_tab_shortcut)

        close_tab_shortcut = QAction(self)
        close_tab_shortcut.setShortcut(QKeySequence("Ctrl+W"))
        close_tab_shortcut.triggered.connect(lambda: self.close_tab(self.tab_widget.currentIndex()))
        self.addAction(close_tab_shortcut)

        private_shortcut = QAction(self)
        private_shortcut.setShortcut(QKeySequence("Ctrl+Shift+N"))
        private_shortcut.triggered.connect(self.new_private_window)
        self.addAction(private_shortcut)

        dev_shortcut = QAction(self)
        dev_shortcut.setShortcut(QKeySequence("F12"))
        dev_shortcut.triggered.connect(lambda: self.current_view().page().triggerAction(
            QWebEnginePage.InspectElement
        ))
        self.addAction(dev_shortcut)

    # -------------------- UI Update --------------------
    def update_ui_texts(self):
        """Update all UI texts according to current language."""
        t = self.translations[self.language]
        self.setWindowTitle(t["app_title"])
        self.back_btn.setToolTip(t["back_tip"])
        self.forward_btn.setToolTip(t["forward_tip"])
        self.reload_btn.setToolTip(t["reload_tip"])
        self.home_btn.setToolTip(t["home_tip"])
        self.bookmark_btn.setToolTip(t["bookmark_tip"])
        self.settings_btn.setToolTip(t["settings"])
        self.url_bar.setPlaceholderText(t["placeholder"])
        self.new_tab_btn.setText(t["new_tab"])

        # Menus
        self.file_menu.setTitle(t["file_menu"])
        self.new_tab_action.setText(t["new_tab_action"])
        self.new_window_action.setText(t["new_window_action"])
        self.new_private_action.setText(t["new_private_action"])
        self.close_tab_action.setText(t["close_tab_action"])

        self.history_menu.setTitle(t["history_menu"])
        self.show_history_action.setText(t["show_history"])
        self.clear_history_action.setText(t["clear_history"])

        self.bookmarks_menu.setTitle(t["bookmarks_menu"])
        self.add_bookmark_action.setText(t["add_bookmark"])
        self.manage_bookmarks_action.setText(t["manage_bookmarks"])

        self.settings_menu.setTitle(t["settings_menu"])
        self.preferences_action.setText(t["preferences"])

        self.dev_menu.setTitle(t["developer_menu"])
        self.dev_tools_action.setText(t["dev_tools"])

        # Update existing tab titles (only those with default names)
        for i in range(self.tab_widget.count()):
            view = self.tab_widget.widget(i)
            if view and view.url().toString() in (NEW_TAB_URL, SETTINGS_URL):
                # For internal pages, we keep their own titles, but we can update new tab title
                pass

    def apply_theme(self, theme):
        self.theme = theme
        if theme == "dark":
            dark_style = """
                QMainWindow, QWidget {
                    background: #1e1e1e;
                    color: #e0e0e0;
                }
                QToolBar {
                    background: #252525;
                    border: none;
                    padding: 4px;
                }
                QLineEdit {
                    background: #333;
                    color: #eee;
                    border: 1px solid #555;
                    border-radius: 3px;
                    padding: 6px;
                }
                QTabWidget::pane {
                    border: 1px solid #444;
                    background: #222;
                }
                QTabBar::tab {
                    background: #333;
                    color: #ccc;
                    padding: 8px 16px;
                    margin-right: 2px;
                }
                QTabBar::tab:selected {
                    background: #444;
                    color: #fff;
                }
                QStatusBar {
                    background: #252525;
                    color: #ccc;
                }
                QPushButton {
                    background: #444;
                    color: #eee;
                    border: 1px solid #555;
                    border-radius: 3px;
                    padding: 6px 12px;
                }
                QPushButton:hover {
                    background: #555;
                }
                QComboBox {
                    background: #333;
                    color: #eee;
                    border: 1px solid #555;
                    border-radius: 3px;
                    padding: 4px;
                }
            """
            self.setStyleSheet(dark_style)
        else:
            self.setStyleSheet("")

    def apply_ua(self):
        """Apply user agent based on ua_mode."""
        if self.ua_mode == "mobile":
            ua = "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1"
        else:
            ua = ""
        QWebEngineProfile.defaultProfile().setHttpUserAgent(ua)
        # Reload current page to apply new UA
        view = self.current_view()
        if view and view.url().isValid() and view.url().scheme() not in ("crazy-browser", "about", "chrome"):
            view.reload()

    def save_all_settings(self):
        """Save all settings to config file."""
        self.config["language"] = self.language
        self.config["theme"] = self.theme
        self.config["ua_mode"] = self.ua_mode
        DataManager.save_json(CONFIG_FILE, self.config)

    # -------------------- Tab Management --------------------
    def new_tab(self, url=None, title=None):
        """Create a new tab. If url is None, load newtab page."""
        view = CrazyWebView(self, is_private=self.is_private)
        if url is None:
            view.load_new_tab_page()
            display_title = "New Tab"
        else:
            view.setUrl(QUrl(url))
            display_title = title or "Untitled"

        index = self.tab_widget.addTab(view, display_title)
        self.tab_widget.setCurrentIndex(index)

        view.urlChanged.connect(lambda qurl: self.update_url_bar(qurl, view))
        view.titleChanged.connect(lambda t: self.update_tab_title(view, t))
        view.loadProgress.connect(lambda p: self.update_status(p, view))
        view.loadFinished.connect(lambda ok: self.record_history_if_needed(view))
        return view

    def close_tab(self, index):
        if self.tab_widget.count() > 1:
            self.tab_widget.removeTab(index)
        else:
            self.close()

    def current_view(self):
        return self.tab_widget.currentWidget()

    def on_tab_changed(self, index):
        if index >= 0:
            view = self.tab_widget.widget(index)
            if view:
                self.update_url_bar(view.url(), view)
                self.setWindowTitle(self.translations[self.language]["app_title"] + " - " + view.title())

    def update_tab_title(self, view, title):
        idx = self.tab_widget.indexOf(view)
        if idx >= 0:
            short = title[:20] + "..." if len(title) > 20 else title
            self.tab_widget.setTabText(idx, short)
            if view == self.current_view():
                self.setWindowTitle(self.translations[self.language]["app_title"] + " - " + title)

    # -------------------- Navigation --------------------
    def navigate_to_url(self):
        text = self.url_bar.text().strip()
        if not text:
            return
        if "." in text or text.startswith("chrome://") or text.startswith("http"):
            if not text.startswith("http") and not text.startswith("chrome://"):
                text = "http://" + text
            url = QUrl.fromUserInput(text)
        else:
            search_url = self.config["search_engine"].format(text)
            url = QUrl(search_url)
        self.current_view().setUrl(url)

    def go_home(self):
        self.current_view().setUrl(QUrl(self.config["home_url"]))

    def open_settings_page(self):
        """Open the settings internal page in a new or current tab."""
        # Check if already open
        for i in range(self.tab_widget.count()):
            view = self.tab_widget.widget(i)
            if view and view.url().toString().startswith(SETTINGS_URL):
                self.tab_widget.setCurrentIndex(i)
                return
        self.new_tab(SETTINGS_URL, "Settings")

    def update_url_bar(self, url, view):
        if view == self.current_view():
            self.url_bar.setText(url.toString())

    def update_status(self, progress, view):
        if view == self.current_view():
            self.status_bar.showMessage(self.translations[self.language]["status_loading"].format(progress))

    def record_history_if_needed(self, view):
        if not view.is_private and view.url().isValid():
            url_str = view.url().toString()
            if url_str not in (NEW_TAB_URL, SETTINGS_URL) and not url_str.startswith("crazy-browser://"):
                if not self.history_data or self.history_data[-1]["url"] != url_str:
                    self.history_data.append({
                        "url": url_str,
                        "title": view.title(),
                        "time": datetime.now().isoformat()
                    })
                    DataManager.save_json(HISTORY_FILE, self.history_data)

    # -------------------- Window Management --------------------
    def new_window(self):
        win = CrazyBrowser(is_private=False)
        win.show()

    def new_private_window(self):
        win = CrazyBrowser(is_private=True)
        win.show()

    # -------------------- Bookmarks --------------------
    def add_current_bookmark(self):
        view = self.current_view()
        url = view.url().toString()
        title = view.title()
        if not url or url == "about:blank" or url.startswith("crazy-browser://"):
            return
        for b in self.bookmarks:
            if b["url"] == url:
                QMessageBox.information(self, self.translations[self.language]["bookmarks_menu"],
                                        self.translations[self.language]["bookmark_exists"])
                return
        self.bookmarks.append({"url": url, "title": title})
        DataManager.save_json(BOOKMARKS_FILE, self.bookmarks)
        QMessageBox.information(self, self.translations[self.language]["bookmarks_menu"],
                                self.translations[self.language]["bookmark_added"].format(title))

    def show_bookmarks_dialog(self):
        t = self.translations[self.language]
        if not self.bookmarks:
            QMessageBox.information(self, t["bookmarks_menu"], t["no_bookmarks"])
            return
        dlg = QDialog(self)
        dlg.setWindowTitle(t["manage_bookmarks_title"])
        dlg.resize(500, 400)
        layout = QVBoxLayout()
        list_widget = QListWidget()
        for b in self.bookmarks:
            item = QListWidgetItem(f"{b['title']} - {b['url']}")
            item.setData(Qt.UserRole, b)
            list_widget.addItem(item)
        layout.addWidget(list_widget)

        btn_layout = QHBoxLayout()
        open_btn = QPushButton(t["open"])
        delete_btn = QPushButton(t["delete"])
        close_btn = QPushButton(t["close"])

        def open_bookmark():
            item = list_widget.currentItem()
            if item:
                b = item.data(Qt.UserRole)
                self.new_tab(b["url"], b["title"])
                dlg.accept()

        def delete_bookmark():
            item = list_widget.currentItem()
            if item:
                b = item.data(Qt.UserRole)
                self.bookmarks = [x for x in self.bookmarks if x["url"] != b["url"]]
                DataManager.save_json(BOOKMARKS_FILE, self.bookmarks)
                list_widget.takeItem(list_widget.row(item))

        open_btn.clicked.connect(open_bookmark)
        delete_btn.clicked.connect(delete_bookmark)
        close_btn.clicked.connect(dlg.accept)

        btn_layout.addWidget(open_btn)
        btn_layout.addWidget(delete_btn)
        btn_layout.addWidget(close_btn)
        layout.addLayout(btn_layout)
        dlg.setLayout(layout)
        dlg.exec_()

    # -------------------- History --------------------
    def show_history_dialog(self):
        t = self.translations[self.language]
        if not self.history_data:
            QMessageBox.information(self, t["history_menu"], t["no_history"])
            return
        dlg = QDialog(self)
        dlg.setWindowTitle(t["history_title"])
        dlg.resize(600, 400)
        layout = QVBoxLayout()
        list_widget = QListWidget()
        for h in reversed(self.history_data):
            item = QListWidgetItem(f"{h['title']} - {h['url']}  ({h['time'][:16]})")
            item.setData(Qt.UserRole, h)
            list_widget.addItem(item)
        layout.addWidget(list_widget)

        btn_layout = QHBoxLayout()
        open_btn = QPushButton(t["open"])
        close_btn = QPushButton(t["close"])

        def open_history():
            item = list_widget.currentItem()
            if item:
                h = item.data(Qt.UserRole)
                self.new_tab(h["url"], h["title"])
                dlg.accept()

        open_btn.clicked.connect(open_history)
        close_btn.clicked.connect(dlg.accept)
        btn_layout.addWidget(open_btn)
        btn_layout.addWidget(close_btn)
        layout.addLayout(btn_layout)
        dlg.setLayout(layout)
        dlg.exec_()

    def clear_history(self):
        self.history_data = []
        DataManager.save_json(HISTORY_FILE, self.history_data)
        QMessageBox.information(self, self.translations[self.language]["history_menu"],
                                self.translations[self.language]["history_cleared"])


# -------------------- Entry Point --------------------
if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setApplicationName("crazy_browser")
    main_window = CrazyBrowser(is_private=False)
    main_window.show()
    sys.exit(app.exec_())