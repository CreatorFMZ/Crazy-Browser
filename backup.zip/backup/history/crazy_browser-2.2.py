# crazy_browser-2.2.py
# 一个用 Python + PyQt6 写的浏览器
# 优化版本：修复bug，清理代码，提升用户体验

import sys
from PyQt6.QtWidgets import (
    QApplication,
    QMainWindow,
    QLineEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
    QToolBar,
    QTabWidget,
    QLabel,
    QProgressBar,
    QComboBox,
    QMessageBox,
    QDialog,
    QFormLayout,
    QRadioButton,
    QDialogButtonBox,
    QGroupBox,
    QCheckBox
)
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebEngineCore import QWebEngineProfile, QWebEnginePage
from PyQt6.QtCore import QUrl, QSize
from PyQt6.QtGui import QAction, QIcon


class BrowserTab(QWebEngineView):
    """浏览器标签页类"""
    def __init__(self, parent=None):
        super().__init__(parent)
        if hasattr(parent, 'update_progress'):
            self.loadProgress.connect(parent.update_progress)


class SettingsDialog(QDialog):
    """设置对话框"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("设置")
        self.setFixedSize(380, 200)

        layout = QFormLayout()

        # 主题设置
        theme_group = QGroupBox("界面主题")
        theme_layout = QVBoxLayout()
        self.light_radio = QRadioButton("浅色模式")
        self.dark_radio = QRadioButton("深色模式")
        self.light_radio.setChecked(True)
        theme_layout.addWidget(self.light_radio)
        theme_layout.addWidget(self.dark_radio)
        theme_group.setLayout(theme_layout)
        layout.addRow(theme_group)

        # 隐私设置
        privacy_group = QGroupBox("隐私设置")
        privacy_layout = QVBoxLayout()
        self.persist_check = QCheckBox("保留历史记录和登录状态")
        self.persist_check.setChecked(True)
        privacy_layout.addWidget(self.persist_check)

        # 清除数据按钮
        clear_btn = QPushButton("清除浏览器数据")
        clear_btn.clicked.connect(self.clear_browser_data)
        privacy_layout.addWidget(clear_btn)
        privacy_group.setLayout(privacy_layout)
        layout.addRow(privacy_group)

        # 确定/取消按钮
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | 
            QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)

        self.setLayout(layout)

    def clear_browser_data(self):
        """清除浏览器数据"""
        reply = QMessageBox.question(
            self, "确认清除",
            "确定要清除所有缓存、Cookie和历史记录吗？\n此操作不可撤销。",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            profile = QWebEngineProfile.defaultProfile()
            profile.clearHttpCache()
            profile.clearAllVisitedLinks()
            
            # 清除Cookie
            cookie_store = profile.cookieStore()
            cookie_store.deleteAllCookies()
            
            QMessageBox.information(self, "操作完成", "浏览器数据已清除")
            
            # 刷新所有标签页
            if hasattr(self.parent(), 'refresh_all_tabs'):
                self.parent().refresh_all_tabs()


class CrazyBrowser(QMainWindow):
    """主浏览器窗口"""
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Crazy Browser 2.2 © Fantastic Star")
        self.resize(1280, 860)

        # 浏览器配置
        self.profile = QWebEngineProfile.defaultProfile()
        self.home_url = "https://www.google.com"
        
        # 初始化UI组件
        self.init_ui_components()
        
        # 设置工具栏
        self.setup_toolbar()
        
        # 设置主布局
        self.setup_main_layout()
        
        # 打开第一个标签页
        self.add_new_tab(self.home_url, "首页")
        
        # 应用默认主题
        self.apply_light_theme()

    def init_ui_components(self):
        """初始化UI组件"""
        # 标签页控件
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.currentChanged.connect(self.update_ui_from_current_tab)
        
        # URL地址栏
        self.url_bar = QLineEdit()
        self.url_bar.setPlaceholderText("输入网址或搜索内容...")
        self.url_bar.returnPressed.connect(self.navigate_to_url)
        
        # 进度条
        self.progress_bar = QProgressBar()
        self.progress_bar.setMaximum(100)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setFixedHeight(3)
        self.progress_bar.setVisible(False)
        
        # 用户代理选择
        self.ua_combo = QComboBox()
        self.ua_combo.addItems(["桌面模式", "手机模式"])
        self.ua_combo.currentIndexChanged.connect(self.change_user_agent)

    def setup_toolbar(self):
        """设置工具栏"""
        navbar = QToolBar("导航栏")
        navbar.setMovable(False)
        self.addToolBar(navbar)
        
        # 导航按钮
        self.back_btn = QAction("←", self)
        self.back_btn.setToolTip("后退")
        self.back_btn.triggered.connect(self.go_back)
        navbar.addAction(self.back_btn)
        
        self.forward_btn = QAction("→", self)
        self.forward_btn.setToolTip("前进")
        self.forward_btn.triggered.connect(self.go_forward)
        navbar.addAction(self.forward_btn)
        
        self.reload_btn = QAction("↻", self)
        self.reload_btn.setToolTip("刷新")
        self.reload_btn.triggered.connect(self.reload_page)
        navbar.addAction(self.reload_btn)
        
        self.home_btn = QAction("🏠", self)
        self.home_btn.setToolTip("主页")
        self.home_btn.triggered.connect(self.go_home)
        navbar.addAction(self.home_btn)
        
        # URL地址栏
        navbar.addWidget(self.url_bar)
        
        # 用户代理选择
        navbar.addWidget(QLabel(" 设备: "))
        navbar.addWidget(self.ua_combo)
        
        # 新标签页按钮
        new_tab_btn = QPushButton("+ 新标签页")
        new_tab_btn.clicked.connect(self.add_new_tab)
        navbar.addWidget(new_tab_btn)
        
        # 设置按钮
        settings_btn = QPushButton("⚙ 设置")
        settings_btn.clicked.connect(self.show_settings)
        navbar.addWidget(settings_btn)

    def setup_main_layout(self):
        """设置主布局"""
        central = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self.progress_bar)
        layout.addWidget(self.tabs)
        central.setLayout(layout)
        self.setCentralWidget(central)

    def add_new_tab(self, url=None, title="新标签页"):
        """添加新标签页"""
        if url is None:
            url = self.home_url

        # 创建标签页
        page = QWebEnginePage(self.profile, self)
        view = BrowserTab(self)
        view.setPage(page)
        view.setUrl(QUrl(url))
        
        # 连接信号
        view.titleChanged.connect(
            lambda t: self.tabs.setTabText(self.tabs.indexOf(view), (t or "新标签页")[:30])
        )
        view.urlChanged.connect(self.sync_url_bar)
        view.loadStarted.connect(self.page_load_started)
        view.loadFinished.connect(self.page_load_finished)
        
        # 添加到标签页控件
        index = self.tabs.addTab(view, title)
        self.tabs.setCurrentIndex(index)
        
        return view

    def page_load_started(self):
        """页面开始加载"""
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(True)

    def page_load_finished(self, ok):
        """页面加载完成"""
        self.progress_bar.setValue(100)
        if ok:
            self.progress_bar.setVisible(False)
        
        # 更新导航按钮状态
        view = self.current_view()
        if view:
            self.back_btn.setEnabled(view.history().canGoBack())
            self.forward_btn.setEnabled(view.history().canGoForward())

    def close_tab(self, index):
        """关闭标签页"""
        if self.tabs.count() > 1:
            widget = self.tabs.widget(index)
            self.tabs.removeTab(index)
            widget.deleteLater()

    def current_view(self):
        """获取当前标签页"""
        return self.tabs.currentWidget()

    def go_back(self):
        """后退"""
        view = self.current_view()
        if view:
            view.back()

    def go_forward(self):
        """前进"""
        view = self.current_view()
        if view:
            view.forward()

    def reload_page(self):
        """刷新页面"""
        view = self.current_view()
        if view:
            view.reload()

    def go_home(self):
        """返回主页"""
        view = self.current_view()
        if view:
            view.setUrl(QUrl(self.home_url))

    def navigate_to_url(self):
        """导航到URL"""
        text = self.url_bar.text().strip()
        if not text:
            return
            
        # 处理URL格式
        if not text.startswith(("http://", "https://")):
            if "." in text:  # 可能是域名
                text = "https://" + text
            else:  # 可能是搜索词
                text = f"https://www.google.com/search?q={text}"
                
        # 导航
        view = self.current_view()
        if view:
            view.setUrl(QUrl(text))

    def sync_url_bar(self, qurl):
        """同步URL地址栏"""
        if self.tabs.currentWidget() == self.sender():
            self.url_bar.setText(qurl.toString())
            self.url_bar.setCursorPosition(0)

    def update_ui_from_current_tab(self, index):
        """从当前标签页更新UI"""
        if index < 0:
            return
            
        view = self.tabs.widget(index)
        if view:
            self.url_bar.setText(view.url().toString())
            
            # 更新导航按钮状态
            self.back_btn.setEnabled(view.history().canGoBack())
            self.forward_btn.setEnabled(view.history().canGoForward())

    def update_progress(self, value):
        """更新进度条"""
        self.progress_bar.setValue(value)

    def change_user_agent(self, index):
        """更改用户代理"""
        ua = ""
        if index == 1:  # 手机模式
            ua = "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1"
        
        self.profile.setHttpUserAgent(ua)
        
        # 重新加载当前页面
        view = self.current_view()
        if view and view.url().toString():
            view.reload()

    def show_settings(self):
        """显示设置对话框"""
        dialog = SettingsDialog(self)
        
        # 加载当前设置
        current_theme = "light" if self.styleSheet() == "" else "dark"
        if current_theme == "dark":
            dialog.dark_radio.setChecked(True)
        else:
            dialog.light_radio.setChecked(True)
        
        if dialog.exec() == QDialog.DialogCode.Accepted:
            # 应用主题
            if dialog.dark_radio.isChecked():
                self.apply_dark_theme()
            else:
                self.apply_light_theme()
            
            # 显示持久化设置提示
            if not dialog.persist_check.isChecked():
                QMessageBox.information(
                    self, "提示",
                    "隐私设置将在浏览器重启后生效"
                )

    def apply_dark_theme(self):
        """应用深色主题"""
        dark_theme = """
            QMainWindow, QWidget {
                background: #1e1e1e;
                color: #e0e0e0;
            }
            QToolBar {
                background: #252525;
                border: none;
                padding: 4px;
            }
            QLineEdit {
                background: #333;
                color: #eee;
                border: 1px solid #555;
                border-radius: 3px;
                padding: 6px;
            }
            QTabWidget::pane {
                border: 1px solid #444;
                background: #222;
            }
            QTabBar::tab {
                background: #333;
                color: #ccc;
                padding: 8px 16px;
                margin-right: 2px;
            }
            QTabBar::tab:selected {
                background: #444;
                color: #fff;
            }
            QProgressBar {
                background: #333;
                border: none;
            }
            QProgressBar::chunk {
                background: #4CAF50;
            }
            QPushButton {
                background: #444;
                color: #eee;
                border: 1px solid #555;
                border-radius: 3px;
                padding: 6px 12px;
            }
            QPushButton:hover {
                background: #555;
            }
            QComboBox {
                background: #333;
                color: #eee;
                border: 1px solid #555;
                border-radius: 3px;
                padding: 4px;
            }
        """
        self.setStyleSheet(dark_theme)

    def apply_light_theme(self):
        """应用浅色主题"""
        self.setStyleSheet("")

    def refresh_all_tabs(self):
        """刷新所有标签页"""
        for i in range(self.tabs.count()):
            view = self.tabs.widget(i)
            if view and view.url().toString():
                view.reload()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # 设置应用程序图标（可选）
    # app.setWindowIcon(QIcon("browser_icon.png"))
    
    window = CrazyBrowser()
    window.show()
    
    sys.exit(app.exec())