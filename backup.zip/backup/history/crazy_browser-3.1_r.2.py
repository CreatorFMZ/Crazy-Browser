import sys
import json
import os
from datetime import datetime
from urllib.parse import urlparse, parse_qs
from PyQt5.QtCore import QUrl, Qt
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QTabWidget, QToolBar, QLineEdit,
    QPushButton, QStatusBar, QVBoxLayout, QHBoxLayout,
    QMenu, QAction, QDialog, QListWidget, QListWidgetItem,
    QMessageBox, QComboBox, QDialogButtonBox, QFormLayout,
    QFileDialog
)
from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEngineProfile, QWebEnginePage
from PyQt5.QtGui import QKeySequence

# -------------------- Constants --------------------
CONFIG_FILE = "crazy_browser_config.json"
BOOKMARKS_FILE = "crazy_browser_bookmarks.json"
HISTORY_FILE = "crazy_browser_history.json"
NEW_TAB_URL = "crazy://newtab"
SETTINGS_URL = "crazy://settings"

# -------------------- Data Manager --------------------
class DataManager:
    @staticmethod
    def load_json(file, default):
        try:
            with open(file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return default

    @staticmethod
    def save_json(file, data):
        with open(file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

# -------------------- Custom Web Page (handles crazy:// protocol) --------------------
class CrazyWebPage(QWebEnginePage):
    def __init__(self, view, parent=None):
        super().__init__(parent)
        self.view = view  # reference to CrazyWebView

    def acceptNavigationRequest(self, url, navigationType, isMainFrame):
        """Intercept all navigation requests. Handle crazy:// URLs internally."""
        url_str = url.toString()

        if url_str.startswith("crazy://"):
            main = self.view.get_main_window()

            if url_str == NEW_TAB_URL:
                self.view.load_new_tab_page()
                return False  # block default handling

            elif url_str.startswith(SETTINGS_URL):
                # Parse query parameters (if any)
                parsed = urlparse(url_str)
                params = parse_qs(parsed.query)
                if 'save' in params and main:
                    lang = params.get('lang', ['en'])[0]
                    theme = params.get('theme', ['light'])[0]
                    main.config['language'] = lang
                    main.config['theme'] = theme
                    DataManager.save_json(CONFIG_FILE, main.config)
                    main.apply_theme()
                    # Reload settings page (without save params to avoid loop)
                    self.view.load_settings_page()
                else:
                    self.view.load_settings_page()
                return False

            else:
                # Unknown crazy:// action – ignore
                return False

        # For all other URLs, allow default navigation
        return super().acceptNavigationRequest(url, navigationType, isMainFrame)

# -------------------- Custom Web View --------------------
class CrazyWebView(QWebEngineView):
    def __init__(self, parent=None, is_private=False):
        super().__init__(parent)
        self.is_private = is_private
        self.download_progress = 0

        # Use custom page to handle crazy:// protocol
        self.setPage(CrazyWebPage(self, self))

        # Private browsing profile
        if is_private:
            self.page().profile().setPersistentStoragePolicy(
                QWebEngineProfile.MemoryStorage
            )
            self.page().profile().setPersistentCookiesPolicy(
                QWebEngineProfile.NoPersistentCookies
            )

        # Download handler
        self.page().profile().downloadRequested.connect(self.handle_download)

        # Context menu with DevTools
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.open_context_menu)

    def get_main_window(self):
        """Traverse up to find the main CrazyBrowser instance."""
        p = self.parent()
        while p:
            if isinstance(p, CrazyBrowser):
                return p
            p = p.parent()
        return None

    def createWindow(self, window_type):
        """Open target="_blank" links in a new tab."""
        main = self.get_main_window()
        if main:
            new_view = CrazyWebView(parent=None, is_private=self.is_private)
            index = main.tab_widget.addTab(new_view, "New Tab")
            main.tab_widget.setCurrentIndex(index)
            new_view.titleChanged.connect(lambda t: main.update_tab_title(new_view, t))
            new_view.urlChanged.connect(lambda qurl: main.update_url_bar(qurl, new_view))
            new_view.loadProgress.connect(lambda p: main.update_status(p, new_view))
            new_view.loadFinished.connect(lambda ok: main.record_history_if_needed(new_view))
            return new_view
        return super().createWindow(window_type)

    def setUrl(self, url):
        """Override to handle crazy:// URLs when set programmatically (e.g., from address bar)."""
        url_str = url.toString()

        # For crazy:// URLs, handle them internally and don't call super()
        if url_str.startswith("crazy://"):
            main = self.get_main_window()
            if url_str == NEW_TAB_URL:
                self.load_new_tab_page()
                self.urlChanged.emit(QUrl(NEW_TAB_URL))
                return
            elif url_str.startswith(SETTINGS_URL):
                # Parse query for saving settings (if called with save params)
                parsed = urlparse(url_str)
                params = parse_qs(parsed.query)
                if 'save' in params and main:
                    lang = params.get('lang', ['en'])[0]
                    theme = params.get('theme', ['light'])[0]
                    main.config['language'] = lang
                    main.config['theme'] = theme
                    DataManager.save_json(CONFIG_FILE, main.config)
                    main.apply_theme()
                    self.load_settings_page()
                    self.urlChanged.emit(QUrl(SETTINGS_URL))
                    return
                else:
                    self.load_settings_page()
                    self.urlChanged.emit(QUrl(SETTINGS_URL))
                    return
            else:
                # Unknown crazy:// – fallback to new tab
                self.load_new_tab_page()
                self.urlChanged.emit(QUrl(NEW_TAB_URL))
                return

        # Normal URL – pass to parent
        super().setUrl(url)

    def load_new_tab_page(self):
        """Load the custom new tab page with a search box."""
        main = self.get_main_window()
        search_engine = main.config.get("search_engine", "https://www.bing.com/search?q={}") if main else "https://www.bing.com/search?q={}"
        language = main.config.get("language", "en") if main else "en"

        if language == "zh":
            welcome = "🌐 crazy_browser"
            placeholder = "搜索或输入地址..."
            btn_text = "搜索"
        else:
            welcome = "🌐 crazy_browser"
            placeholder = "Search or enter address..."
            btn_text = "Search"

        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>New Tab</title>
            <style>
                body {{
                    margin: 0;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    background: #1a1a1a;
                    font-family: Arial, sans-serif;
                }}
                .container {{
                    text-align: center;
                    padding: 40px;
                    background: #2d2d2d;
                    border-radius: 20px;
                    box-shadow: 0 10px 40px rgba(0,0,0,0.6);
                }}
                h1 {{
                    color: #ffffff;
                    font-size: 36px;
                    margin-bottom: 30px;
                }}
                .search-box {{
                    display: flex;
                    justify-content: center;
                    gap: 10px;
                }}
                #search-input {{
                    width: 400px;
                    padding: 14px 20px;
                    font-size: 18px;
                    border: none;
                    border-radius: 30px;
                    outline: none;
                    background: #3d3d3d;
                    color: #ffffff;
                }}
                #search-btn {{
                    padding: 14px 28px;
                    font-size: 18px;
                    border: none;
                    border-radius: 30px;
                    background: #4a90d9;
                    color: #fff;
                    cursor: pointer;
                    transition: background 0.2s;
                }}
                #search-btn:hover {{
                    background: #5a9ef0;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>{welcome}</h1>
                <div class="search-box">
                    <input id="search-input" type="text" placeholder="{placeholder}" autofocus>
                    <button id="search-btn">{btn_text}</button>
                </div>
            </div>
            <script>
                const input = document.getElementById('search-input');
                const btn = document.getElementById('search-btn');
                function doSearch() {{
                    const q = input.value.trim();
                    if (!q) return;
                    const engine = '{search_engine}';
                    const url = engine.replace('{{}}', encodeURIComponent(q));
                    window.location.href = url;
                }}
                btn.addEventListener('click', doSearch);
                input.addEventListener('keydown', (e) => {{
                    if (e.key === 'Enter') doSearch();
                }});
            </script>
        </body>
        </html>
        """
        self.setHtml(html, baseUrl=QUrl(NEW_TAB_URL))

    def load_settings_page(self):
        """Load the settings page with language and theme options."""
        main = self.get_main_window()
        if not main:
            return
        config = main.config
        lang = config.get("language", "en")
        theme = config.get("theme", "light")

        lang_options = ""
        for value, label in [("en", "English"), ("zh", "中文")]:
            selected = "selected" if value == lang else ""
            lang_options += f'<option value="{value}" {selected}>{label}</option>'

        theme_options = ""
        for value, label in [("light", "Light"), ("dark", "Dark")]:
            selected = "selected" if value == theme else ""
            theme_options += f'<option value="{value}" {selected}>{label}</option>'

        if lang == "zh":
            page_title = "设置"
            lang_label = "语言"
            theme_label = "主题"
            save_btn = "保存"
        else:
            page_title = "Settings"
            lang_label = "Language"
            theme_label = "Theme"
            save_btn = "Save"

        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>{page_title}</title>
            <style>
                body {{
                    margin: 0;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    background: #1a1a1a;
                    font-family: Arial, sans-serif;
                }}
                .container {{
                    text-align: center;
                    padding: 40px;
                    background: #2d2d2d;
                    border-radius: 20px;
                    box-shadow: 0 10px 40px rgba(0,0,0,0.6);
                    color: #ffffff;
                    width: 400px;
                }}
                h1 {{
                    color: #ffffff;
                    font-size: 32px;
                    margin-bottom: 30px;
                }}
                .field {{
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin: 15px 0;
                    font-size: 18px;
                }}
                select {{
                    padding: 8px 16px;
                    font-size: 16px;
                    border: none;
                    border-radius: 8px;
                    background: #3d3d3d;
                    color: #ffffff;
                    outline: none;
                }}
                select option {{
                    background: #2d2d2d;
                }}
                #save-btn {{
                    margin-top: 20px;
                    padding: 12px 32px;
                    font-size: 18px;
                    border: none;
                    border-radius: 30px;
                    background: #4a90d9;
                    color: #fff;
                    cursor: pointer;
                    transition: background 0.2s;
                }}
                #save-btn:hover {{
                    background: #5a9ef0;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>{page_title}</h1>
                <div class="field">
                    <span>{lang_label}</span>
                    <select id="lang-select">
                        {lang_options}
                    </select>
                </div>
                <div class="field">
                    <span>{theme_label}</span>
                    <select id="theme-select">
                        {theme_options}
                    </select>
                </div>
                <button id="save-btn">{save_btn}</button>
            </div>
            <script>
                document.getElementById('save-btn').addEventListener('click', function() {{
                    const lang = document.getElementById('lang-select').value;
                    const theme = document.getElementById('theme-select').value;
                    window.location.href = 'crazy://settings?save=1&lang=' + encodeURIComponent(lang) + '&theme=' + encodeURIComponent(theme);
                }});
            </script>
        </body>
        </html>
        """
        self.setHtml(html, baseUrl=QUrl(SETTINGS_URL))

    def handle_download(self, download):
        """Save downloaded file."""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Save File", download.suggestedFileName()
        )
        if file_path:
            download.setPath(file_path)
            download.accept()
            download.downloadProgress.connect(
                lambda r, t: self.parent().parent().statusBar().showMessage(
                    f"Downloading: {download.suggestedFileName()} {int(r/t*100)}%"
                ) if self.parent() else None
            )
            download.finished.connect(
                lambda: self.parent().parent().statusBar().showMessage(
                    f"Download complete: {os.path.basename(file_path)}"
                ) if self.parent() else None
            )

    def open_context_menu(self, pos):
        menu = self.page().createStandardContextMenu()
        dev_action = QAction("Developer Tools (F12)", self)
        dev_action.triggered.connect(lambda: self.page().triggerAction(
            QWebEnginePage.InspectElement
        ))
        menu.addSeparator()
        menu.addAction(dev_action)
        menu.exec_(self.mapToGlobal(pos))

# -------------------- Main Browser Window --------------------
class CrazyBrowser(QMainWindow):
    def __init__(self, is_private=False, parent=None):
        super().__init__(parent)
        self.is_private = is_private
        self.setWindowTitle("crazy_browser" + (" (Private)" if is_private else ""))
        self.setGeometry(100, 100, 1200, 800)

        # Load config
        self.config = DataManager.load_json(CONFIG_FILE, {
            "home_url": "https://creativesearch.pages.dev",
            "search_engine": "https://www.bing.com/search?q={}",
            "language": "en",
            "theme": "light"
        })
        self.bookmarks = DataManager.load_json(BOOKMARKS_FILE, [])
        self.history_data = DataManager.load_json(HISTORY_FILE, [])

        # Tab widget
        self.tab_widget = QTabWidget()
        self.tab_widget.setTabsClosable(True)
        self.tab_widget.tabCloseRequested.connect(self.close_tab)
        self.tab_widget.currentChanged.connect(self.on_tab_changed)
        self.setCentralWidget(self.tab_widget)

        # Toolbars and menus
        self.create_toolbar()
        self.create_menu_bar()

        # Status bar
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)

        # Apply theme
        self.apply_theme()

        # Initial tab: load home page
        self.new_tab(self.config["home_url"])

        # Keyboard shortcuts
        self.setup_shortcuts()

    def apply_theme(self):
        """Apply light/dark theme to the window."""
        theme = self.config.get("theme", "light")
        if theme == "dark":
            style = """
                QMainWindow, QDialog {
                    background-color: #2b2b2b;
                    color: #ffffff;
                }
                QToolBar, QStatusBar, QMenuBar, QMenu {
                    background-color: #3c3c3c;
                    color: #ffffff;
                }
                QLineEdit, QComboBox, QListWidget {
                    background-color: #3c3c3c;
                    color: #ffffff;
                    border: 1px solid #555;
                }
                QPushButton {
                    background-color: #4a90d9;
                    color: #ffffff;
                    border: none;
                    padding: 6px 12px;
                    border-radius: 4px;
                }
                QPushButton:hover {
                    background-color: #5a9ef0;
                }
                QTabWidget::pane {
                    border: 1px solid #555;
                }
                QTabBar::tab {
                    background-color: #3c3c3c;
                    color: #ffffff;
                    padding: 8px 12px;
                }
                QTabBar::tab:selected {
                    background-color: #4a90d9;
                }
            """
        else:  # light
            style = """
                QMainWindow, QDialog {
                    background-color: #f0f0f0;
                    color: #000000;
                }
                QToolBar, QStatusBar, QMenuBar, QMenu {
                    background-color: #e0e0e0;
                    color: #000000;
                }
                QLineEdit, QComboBox, QListWidget {
                    background-color: #ffffff;
                    color: #000000;
                    border: 1px solid #aaa;
                }
                QPushButton {
                    background-color: #4a90d9;
                    color: #ffffff;
                    border: none;
                    padding: 6px 12px;
                    border-radius: 4px;
                }
                QPushButton:hover {
                    background-color: #5a9ef0;
                }
                QTabWidget::pane {
                    border: 1px solid #aaa;
                }
                QTabBar::tab {
                    background-color: #e0e0e0;
                    color: #000000;
                    padding: 8px 12px;
                }
                QTabBar::tab:selected {
                    background-color: #4a90d9;
                    color: #ffffff;
                }
            """
        self.setStyleSheet(style)

    def create_toolbar(self):
        nav_bar = QToolBar("Navigation")
        self.addToolBar(nav_bar)

        back_btn = QPushButton("←")
        back_btn.clicked.connect(lambda: self.current_view().back())
        nav_bar.addWidget(back_btn)

        forward_btn = QPushButton("→")
        forward_btn.clicked.connect(lambda: self.current_view().forward())
        nav_bar.addWidget(forward_btn)

        reload_btn = QPushButton("↻")
        reload_btn.clicked.connect(lambda: self.current_view().reload())
        nav_bar.addWidget(reload_btn)

        stop_btn = QPushButton("✕")
        stop_btn.clicked.connect(lambda: self.current_view().stop())
        nav_bar.addWidget(stop_btn)

        self.url_bar = QLineEdit()
        self.url_bar.returnPressed.connect(self.navigate_to_url)
        nav_bar.addWidget(self.url_bar)

        home_btn = QPushButton("🏠")
        home_btn.clicked.connect(self.go_home)
        nav_bar.addWidget(home_btn)

        new_tab_btn = QPushButton("+")
        new_tab_btn.clicked.connect(lambda: self.new_tab(None))
        nav_bar.addWidget(new_tab_btn)

        bookmark_btn = QPushButton("☆")
        bookmark_btn.setToolTip("Add bookmark")
        bookmark_btn.clicked.connect(self.add_current_bookmark)
        nav_bar.addWidget(bookmark_btn)

    def create_menu_bar(self):
        menubar = self.menuBar()

        file_menu = menubar.addMenu("File")
        new_tab_action = QAction("New Tab (Ctrl+T)", self)
        new_tab_action.triggered.connect(lambda: self.new_tab(None))
        file_menu.addAction(new_tab_action)

        new_window_action = QAction("New Window", self)
        new_window_action.triggered.connect(self.new_window)
        file_menu.addAction(new_window_action)

        new_private_action = QAction("New Private Window (Ctrl+Shift+N)", self)
        new_private_action.triggered.connect(self.new_private_window)
        file_menu.addAction(new_private_action)

        file_menu.addSeparator()
        close_tab_action = QAction("Close Tab (Ctrl+W)", self)
        close_tab_action.triggered.connect(lambda: self.close_tab(self.tab_widget.currentIndex()))
        file_menu.addAction(close_tab_action)

        history_menu = menubar.addMenu("History")
        show_history_action = QAction("Show All History", self)
        show_history_action.triggered.connect(self.show_history_dialog)
        history_menu.addAction(show_history_action)

        clear_history_action = QAction("Clear History", self)
        clear_history_action.triggered.connect(self.clear_history)
        history_menu.addAction(clear_history_action)

        bookmark_menu = menubar.addMenu("Bookmarks")
        add_bookmark_action = QAction("Add Current Page", self)
        add_bookmark_action.triggered.connect(self.add_current_bookmark)
        bookmark_menu.addAction(add_bookmark_action)

        show_bookmarks_action = QAction("Manage Bookmarks", self)
        show_bookmarks_action.triggered.connect(self.show_bookmarks_dialog)
        bookmark_menu.addAction(show_bookmarks_action)

        settings_menu = menubar.addMenu("Settings")
        settings_action = QAction("Preferences", self)
        settings_action.triggered.connect(self.open_settings_tab)
        settings_menu.addAction(settings_action)

        dev_menu = menubar.addMenu("Developer")
        dev_action = QAction("Developer Tools (F12)", self)
        dev_action.triggered.connect(lambda: self.current_view().page().triggerAction(
            QWebEnginePage.InspectElement
        ))
        dev_menu.addAction(dev_action)

    def setup_shortcuts(self):
        new_tab_shortcut = QAction(self)
        new_tab_shortcut.setShortcut(QKeySequence("Ctrl+T"))
        new_tab_shortcut.triggered.connect(lambda: self.new_tab(None))
        self.addAction(new_tab_shortcut)

        close_tab_shortcut = QAction(self)
        close_tab_shortcut.setShortcut(QKeySequence("Ctrl+W"))
        close_tab_shortcut.triggered.connect(lambda: self.close_tab(self.tab_widget.currentIndex()))
        self.addAction(close_tab_shortcut)

        private_shortcut = QAction(self)
        private_shortcut.setShortcut(QKeySequence("Ctrl+Shift+N"))
        private_shortcut.triggered.connect(self.new_private_window)
        self.addAction(private_shortcut)

        dev_shortcut = QAction(self)
        dev_shortcut.setShortcut(QKeySequence("F12"))
        dev_shortcut.triggered.connect(lambda: self.current_view().page().triggerAction(
            QWebEnginePage.InspectElement
        ))
        self.addAction(dev_shortcut)

    # -------------------- Tab Management --------------------
    def new_tab(self, url=None, title="New Tab"):
        view = CrazyWebView(self, is_private=self.is_private)

        if url is None:
            view.load_new_tab_page()
            display_title = "New Tab"
        elif url == NEW_TAB_URL:
            view.load_new_tab_page()
            display_title = "New Tab"
        elif url == SETTINGS_URL:
            view.load_settings_page()
            display_title = "Settings"
        else:
            view.setUrl(QUrl(url))
            display_title = title

        index = self.tab_widget.addTab(view, display_title)
        self.tab_widget.setCurrentIndex(index)

        view.urlChanged.connect(lambda qurl: self.update_url_bar(qurl, view))
        view.titleChanged.connect(lambda t: self.update_tab_title(view, t))
        view.loadProgress.connect(lambda p: self.update_status(p, view))
        view.loadFinished.connect(lambda ok: self.record_history_if_needed(view))
        return view

    def close_tab(self, index):
        if self.tab_widget.count() > 1:
            self.tab_widget.removeTab(index)
        else:
            self.close()

    def current_view(self):
        return self.tab_widget.currentWidget()

    def on_tab_changed(self, index):
        if index >= 0:
            view = self.tab_widget.widget(index)
            if view:
                self.update_url_bar(view.url(), view)
                self.setWindowTitle("crazy_browser - " + view.title())

    def update_tab_title(self, view, title):
        idx = self.tab_widget.indexOf(view)
        if idx >= 0:
            short = title[:20] + "..." if len(title) > 20 else title
            self.tab_widget.setTabText(idx, short)
            if view == self.current_view():
                self.setWindowTitle("crazy_browser - " + title)

    # -------------------- Navigation --------------------
    def navigate_to_url(self):
        text = self.url_bar.text().strip()
        if not text:
            return
        # Detect if it's a URL
        if "." in text or text.startswith("chrome://") or text.startswith("http") or text.startswith("crazy://"):
            if not text.startswith("http") and not text.startswith("chrome://") and not text.startswith("crazy://"):
                text = "http://" + text
            url = QUrl.fromUserInput(text)
        else:
            search_url = self.config["search_engine"].format(text)
            url = QUrl(search_url)
        self.current_view().setUrl(url)

    def go_home(self):
        self.current_view().setUrl(QUrl(self.config["home_url"]))

    def update_url_bar(self, url, view):
        if view == self.current_view():
            self.url_bar.setText(url.toString())

    def update_status(self, progress, view):
        if view == self.current_view():
            self.status_bar.showMessage(f"Loading {progress}%")

    def record_history_if_needed(self, view):
        if not view.is_private and view.url().isValid():
            url_str = view.url().toString()
            if not self.history_data or self.history_data[-1]["url"] != url_str:
                self.history_data.append({
                    "url": url_str,
                    "title": view.title(),
                    "time": datetime.now().isoformat()
                })
                DataManager.save_json(HISTORY_FILE, self.history_data)

    # -------------------- Window Management --------------------
    def new_window(self):
        win = CrazyBrowser(is_private=False)
        win.show()

    def new_private_window(self):
        win = CrazyBrowser(is_private=True)
        win.show()

    # -------------------- Bookmarks --------------------
    def add_current_bookmark(self):
        view = self.current_view()
        url = view.url().toString()
        title = view.title()
        if not url or url == "about:blank" or url.startswith("crazy://"):
            return
        for b in self.bookmarks:
            if b["url"] == url:
                QMessageBox.information(self, "Bookmark", "Already bookmarked.")
                return
        self.bookmarks.append({"url": url, "title": title})
        DataManager.save_json(BOOKMARKS_FILE, self.bookmarks)
        QMessageBox.information(self, "Bookmark", f"Added: {title}")

    def show_bookmarks_dialog(self):
        if not self.bookmarks:
            QMessageBox.information(self, "Bookmarks", "No bookmarks.")
            return
        dlg = QDialog(self)
        dlg.setWindowTitle("Manage Bookmarks")
        dlg.resize(500, 400)
        layout = QVBoxLayout()
        list_widget = QListWidget()
        for b in self.bookmarks:
            item = QListWidgetItem(f"{b['title']} - {b['url']}")
            item.setData(Qt.UserRole, b)
            list_widget.addItem(item)
        layout.addWidget(list_widget)

        btn_layout = QHBoxLayout()
        open_btn = QPushButton("Open")
        delete_btn = QPushButton("Delete")
        close_btn = QPushButton("Close")

        def open_bookmark():
            item = list_widget.currentItem()
            if item:
                b = item.data(Qt.UserRole)
                self.new_tab(b["url"], b["title"])
                dlg.accept()

        def delete_bookmark():
            item = list_widget.currentItem()
            if item:
                b = item.data(Qt.UserRole)
                self.bookmarks = [x for x in self.bookmarks if x["url"] != b["url"]]
                DataManager.save_json(BOOKMARKS_FILE, self.bookmarks)
                list_widget.takeItem(list_widget.row(item))

        open_btn.clicked.connect(open_bookmark)
        delete_btn.clicked.connect(delete_bookmark)
        close_btn.clicked.connect(dlg.accept)

        btn_layout.addWidget(open_btn)
        btn_layout.addWidget(delete_btn)
        btn_layout.addWidget(close_btn)
        layout.addLayout(btn_layout)
        dlg.setLayout(layout)
        dlg.exec_()

    # -------------------- History --------------------
    def show_history_dialog(self):
        if not self.history_data:
            QMessageBox.information(self, "History", "No history.")
            return
        dlg = QDialog(self)
        dlg.setWindowTitle("History")
        dlg.resize(600, 400)
        layout = QVBoxLayout()
        list_widget = QListWidget()
        for h in reversed(self.history_data):
            item = QListWidgetItem(f"{h['title']} - {h['url']}  ({h['time'][:16]})")
            item.setData(Qt.UserRole, h)
            list_widget.addItem(item)
        layout.addWidget(list_widget)

        btn_layout = QHBoxLayout()
        open_btn = QPushButton("Open")
        close_btn = QPushButton("Close")

        def open_history():
            item = list_widget.currentItem()
            if item:
                h = item.data(Qt.UserRole)
                self.new_tab(h["url"], h["title"])
                dlg.accept()

        open_btn.clicked.connect(open_history)
        close_btn.clicked.connect(dlg.accept)
        btn_layout.addWidget(open_btn)
        btn_layout.addWidget(close_btn)
        layout.addLayout(btn_layout)
        dlg.setLayout(layout)
        dlg.exec_()

    def clear_history(self):
        self.history_data = []
        DataManager.save_json(HISTORY_FILE, self.history_data)
        QMessageBox.information(self, "History", "History cleared.")

    # -------------------- Settings --------------------
    def open_settings_tab(self):
        """Open settings in a new tab."""
        self.new_tab(SETTINGS_URL, "Settings")

    # (Legacy method kept for compatibility)
    def show_settings_dialog(self):
        self.open_settings_tab()

# -------------------- Entry Point --------------------
if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setApplicationName("crazy_browser")
    main_window = CrazyBrowser(is_private=False)
    main_window.show()
    sys.exit(app.exec_())