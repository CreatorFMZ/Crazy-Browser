import sys
import json
import os
from datetime import datetime
from PyQt5.QtCore import QUrl, Qt, QTimer, QStandardPaths
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QTabWidget, QToolBar, QLineEdit,
    QPushButton, QStatusBar, QWidget, QVBoxLayout, QHBoxLayout,
    QMenu, QAction, QDialog, QListWidget, QListWidgetItem,
    QMessageBox, QLabel, QComboBox, QLineEdit as QLineEditWidget,
    QDialogButtonBox, QFormLayout, QFileDialog, QProgressBar
)
from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEngineProfile, QWebEnginePage
from PyQt5.QtGui import QIcon, QKeySequence


# -------------------- 数据持久化 --------------------
CONFIG_FILE = "crazy_browser_config.json"
BOOKMARKS_FILE = "crazy_browser_bookmarks.json"
HISTORY_FILE = "crazy_browser_history.json"

class DataManager:
    @staticmethod
    def load_json(file, default):
        try:
            with open(file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return default

    @staticmethod
    def save_json(file, data):
        with open(file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)


# -------------------- 自定义网页视图 --------------------
class CrazyWebView(QWebEngineView):
    def __init__(self, parent=None, is_private=False):
        super().__init__(parent)
        self.is_private = is_private
        self.download_progress = 0
        self.history_urls = []  # 用于记录本次会话的历史（非私密）

        # 设置 profile（私密模式用 OffTheRecord）
        if is_private:
            self.page().profile().setPersistentStoragePolicy(
                QWebEngineProfile.MemoryStorage
            )
            self.page().profile().setPersistentCookiesPolicy(
                QWebEngineProfile.NoPersistentCookies
            )

        # 下载信号
        self.page().profile().downloadRequested.connect(self.handle_download)

        # 右键菜单增加“开发者工具”
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.open_context_menu)

    def handle_download(self, download):
        """处理下载请求"""
        # 弹出保存对话框
        file_path, _ = QFileDialog.getSaveFileName(
            self, "保存文件", download.suggestedFileName()
        )
        if file_path:
            download.setPath(file_path)
            download.accept()
            # 显示下载进度（简单起见，打印到状态栏，可通过信号传递给主窗口）
            download.downloadProgress.connect(
                lambda r, t: self.parent().parent().statusBar().showMessage(
                    f"下载中: {download.suggestedFileName()} {int(r/t*100)}%"
                ) if self.parent() else None
            )
            download.finished.connect(
                lambda: self.parent().parent().statusBar().showMessage(
                    f"下载完成: {os.path.basename(file_path)}"
                ) if self.parent() else None
            )

    def open_context_menu(self, pos):
        menu = self.page().createStandardContextMenu()
        # 添加开发者工具
        dev_action = QAction("开发者工具 (F12)", self)
        dev_action.triggered.connect(lambda: self.page().triggerAction(
            QWebEnginePage.InspectElement
        ))
        menu.addSeparator()
        menu.addAction(dev_action)
        menu.exec_(self.mapToGlobal(pos))

    def add_history(self, url):
        if not self.is_private and url.isValid() and not url.scheme() in ('chrome', 'about'):
            self.history_urls.append({
                "url": url.toString(),
                "title": self.title(),
                "time": datetime.now().isoformat()
            })


# -------------------- 主浏览器窗口 --------------------
class CrazyBrowser(QMainWindow):
    def __init__(self, is_private=False, parent=None):
        super().__init__(parent)
        self.is_private = is_private
        self.setWindowTitle("crazy_browser" + (" (无痕)" if is_private else ""))
        self.setGeometry(100, 100, 1200, 800)

        # 加载配置
        self.config = DataManager.load_json(CONFIG_FILE, {
            "home_url": "https://search.oneapp.dev",
            "search_engine": "https://www.bing.com/search?q={}"
        })
        self.bookmarks = DataManager.load_json(BOOKMARKS_FILE, [])
        # 历史记录在全局加载，此处只用于显示
        self.history_data = DataManager.load_json(HISTORY_FILE, [])

        # 主布局：标签页
        self.tab_widget = QTabWidget()
        self.tab_widget.setTabsClosable(True)
        self.tab_widget.tabCloseRequested.connect(self.close_tab)
        self.tab_widget.currentChanged.connect(self.on_tab_changed)
        self.setCentralWidget(self.tab_widget)

        # 创建工具栏
        self.create_toolbar()
        self.create_menu_bar()

        # 状态栏
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)

        # 新建初始标签页
        self.new_tab(self.config["home_url"], "首页")

        # 快捷键
        self.setup_shortcuts()

    def create_toolbar(self):
        nav_bar = QToolBar("导航")
        self.addToolBar(nav_bar)

        # 后退
        back_btn = QPushButton("←")
        back_btn.clicked.connect(lambda: self.current_view().back())
        nav_bar.addWidget(back_btn)

        # 前进
        forward_btn = QPushButton("→")
        forward_btn.clicked.connect(lambda: self.current_view().forward())
        nav_bar.addWidget(forward_btn)

        # 刷新
        reload_btn = QPushButton("↻")
        reload_btn.clicked.connect(lambda: self.current_view().reload())
        nav_bar.addWidget(reload_btn)

        # 停止
        stop_btn = QPushButton("✕")
        stop_btn.clicked.connect(lambda: self.current_view().stop())
        nav_bar.addWidget(stop_btn)

        # 地址栏
        self.url_bar = QLineEdit()
        self.url_bar.returnPressed.connect(self.navigate_to_url)
        nav_bar.addWidget(self.url_bar)

        # 首页
        home_btn = QPushButton("🏠")
        home_btn.clicked.connect(self.go_home)
        nav_bar.addWidget(home_btn)

        # 新建标签按钮
        new_tab_btn = QPushButton("+")
        new_tab_btn.clicked.connect(lambda: self.new_tab(self.config["home_url"]))
        nav_bar.addWidget(new_tab_btn)

        # 扩展工具栏：书签、历史等放在菜单里，这里增加一个书签按钮
        bookmark_btn = QPushButton("☆")
        bookmark_btn.setToolTip("添加书签")
        bookmark_btn.clicked.connect(self.add_current_bookmark)
        nav_bar.addWidget(bookmark_btn)

    def create_menu_bar(self):
        menubar = self.menuBar()

        # 文件菜单
        file_menu = menubar.addMenu("文件")
        new_tab_action = QAction("新建标签页 (Ctrl+T)", self)
        new_tab_action.triggered.connect(lambda: self.new_tab(self.config["home_url"]))
        file_menu.addAction(new_tab_action)

        new_window_action = QAction("新建窗口", self)
        new_window_action.triggered.connect(self.new_window)
        file_menu.addAction(new_window_action)

        new_private_action = QAction("新建无痕窗口 (Ctrl+Shift+N)", self)
        new_private_action.triggered.connect(self.new_private_window)
        file_menu.addAction(new_private_action)

        file_menu.addSeparator()
        close_tab_action = QAction("关闭标签页 (Ctrl+W)", self)
        close_tab_action.triggered.connect(lambda: self.close_tab(self.tab_widget.currentIndex()))
        file_menu.addAction(close_tab_action)

        # 历史菜单
        history_menu = menubar.addMenu("历史")
        show_history_action = QAction("显示全部历史", self)
        show_history_action.triggered.connect(self.show_history_dialog)
        history_menu.addAction(show_history_action)

        clear_history_action = QAction("清除历史记录", self)
        clear_history_action.triggered.connect(self.clear_history)
        history_menu.addAction(clear_history_action)

        # 书签菜单
        bookmark_menu = menubar.addMenu("书签")
        add_bookmark_action = QAction("添加当前页到书签", self)
        add_bookmark_action.triggered.connect(self.add_current_bookmark)
        bookmark_menu.addAction(add_bookmark_action)

        show_bookmarks_action = QAction("管理书签", self)
        show_bookmarks_action.triggered.connect(self.show_bookmarks_dialog)
        bookmark_menu.addAction(show_bookmarks_action)

        # 设置菜单
        settings_menu = menubar.addMenu("设置")
        settings_action = QAction("偏好设置", self)
        settings_action.triggered.connect(self.show_settings_dialog)
        settings_menu.addAction(settings_action)

        # 开发者工具（全局）
        dev_menu = menubar.addMenu("开发者")
        dev_action = QAction("开发者工具 (F12)", self)
        dev_action.triggered.connect(lambda: self.current_view().page().triggerAction(
            QWebEnginePage.InspectElement
        ))
        dev_menu.addAction(dev_action)

    def setup_shortcuts(self):
        # Ctrl+T 新建标签
        new_tab_shortcut = QAction(self)
        new_tab_shortcut.setShortcut(QKeySequence("Ctrl+T"))
        new_tab_shortcut.triggered.connect(lambda: self.new_tab(self.config["home_url"]))
        self.addAction(new_tab_shortcut)

        # Ctrl+W 关闭标签
        close_tab_shortcut = QAction(self)
        close_tab_shortcut.setShortcut(QKeySequence("Ctrl+W"))
        close_tab_shortcut.triggered.connect(lambda: self.close_tab(self.tab_widget.currentIndex()))
        self.addAction(close_tab_shortcut)

        # Ctrl+Shift+N 无痕窗口
        private_shortcut = QAction(self)
        private_shortcut.setShortcut(QKeySequence("Ctrl+Shift+N"))
        private_shortcut.triggered.connect(self.new_private_window)
        self.addAction(private_shortcut)

        # F12 开发者工具
        dev_shortcut = QAction(self)
        dev_shortcut.setShortcut(QKeySequence("F12"))
        dev_shortcut.triggered.connect(lambda: self.current_view().page().triggerAction(
            QWebEnginePage.InspectElement
        ))
        self.addAction(dev_shortcut)

    # -------------------- 标签页管理 --------------------
    def new_tab(self, url=None, title="新标签页"):
        view = CrazyWebView(self, is_private=self.is_private)
        if url:
            view.setUrl(QUrl(url))
        else:
            view.setUrl(QUrl(self.config["home_url"]))

        index = self.tab_widget.addTab(view, title)
        self.tab_widget.setCurrentIndex(index)

        # 连接信号
        view.urlChanged.connect(lambda qurl: self.update_url_bar(qurl, view))
        view.titleChanged.connect(lambda t: self.update_tab_title(view, t))
        view.loadProgress.connect(lambda p: self.update_status(p, view))

        # 记录历史（在页面加载完成时）
        view.loadFinished.connect(lambda ok: self.record_history_if_needed(view))
        return view

    def close_tab(self, index):
        if self.tab_widget.count() > 1:
            self.tab_widget.removeTab(index)
        else:
            # 最后一个标签，关闭窗口
            self.close()

    def current_view(self):
        return self.tab_widget.currentWidget()

    def on_tab_changed(self, index):
        if index >= 0:
            view = self.tab_widget.widget(index)
            if view:
                self.update_url_bar(view.url(), view)
                self.setWindowTitle("crazy_browser - " + view.title())

    def update_tab_title(self, view, title):
        idx = self.tab_widget.indexOf(view)
        if idx >= 0:
            self.tab_widget.setTabText(idx, title[:20] + "..." if len(title) > 20 else title)
            if view == self.current_view():
                self.setWindowTitle("crazy_browser - " + title)

    # -------------------- 导航 --------------------
    def navigate_to_url(self):
        text = self.url_bar.text().strip()
        if not text:
            return
        # 检测是否为 URL
        if "." in text or text.startswith("chrome://") or text.startswith("http"):
            if not text.startswith("http") and not text.startswith("chrome://"):
                text = "http://" + text
            url = QUrl.fromUserInput(text)
        else:
            # 使用默认搜索引擎
            search_url = self.config["search_engine"].format(text)
            url = QUrl(search_url)
        self.current_view().setUrl(url)

    def go_home(self):
        self.current_view().setUrl(QUrl(self.config["home_url"]))

    def update_url_bar(self, url, view):
        if view == self.current_view():
            self.url_bar.setText(url.toString())

    def update_status(self, progress, view):
        if view == self.current_view():
            self.status_bar.showMessage(f"加载中 {progress}%")

    def record_history_if_needed(self, view):
        if not view.is_private and view.url().isValid():
            url_str = view.url().toString()
            # 避免记录重复连续加载（简单去重）
            if not self.history_data or self.history_data[-1]["url"] != url_str:
                self.history_data.append({
                    "url": url_str,
                    "title": view.title(),
                    "time": datetime.now().isoformat()
                })
                DataManager.save_json(HISTORY_FILE, self.history_data)

    # -------------------- 窗口管理 --------------------
    def new_window(self):
        win = CrazyBrowser(is_private=False)
        win.show()

    def new_private_window(self):
        win = CrazyBrowser(is_private=True)
        win.show()

    # -------------------- 书签 --------------------
    def add_current_bookmark(self):
        view = self.current_view()
        url = view.url().toString()
        title = view.title()
        if not url or url == "about:blank":
            return
        # 检查是否已存在
        for b in self.bookmarks:
            if b["url"] == url:
                QMessageBox.information(self, "书签", "此页面已在书签中")
                return
        self.bookmarks.append({"url": url, "title": title})
        DataManager.save_json(BOOKMARKS_FILE, self.bookmarks)
        QMessageBox.information(self, "书签", f"已添加书签: {title}")

    def show_bookmarks_dialog(self):
        if not self.bookmarks:
            QMessageBox.information(self, "书签", "暂无书签")
            return
        dlg = QDialog(self)
        dlg.setWindowTitle("书签管理")
        dlg.resize(500, 400)
        layout = QVBoxLayout()
        list_widget = QListWidget()
        for b in self.bookmarks:
            item = QListWidgetItem(f"{b['title']} - {b['url']}")
            item.setData(Qt.UserRole, b)
            list_widget.addItem(item)
        layout.addWidget(list_widget)

        btn_layout = QHBoxLayout()
        open_btn = QPushButton("打开选中")
        delete_btn = QPushButton("删除选中")
        close_btn = QPushButton("关闭")

        def open_bookmark():
            item = list_widget.currentItem()
            if item:
                b = item.data(Qt.UserRole)
                self.new_tab(b["url"], b["title"])
                dlg.accept()

        def delete_bookmark():
            item = list_widget.currentItem()
            if item:
                b = item.data(Qt.UserRole)
                self.bookmarks = [x for x in self.bookmarks if x["url"] != b["url"]]
                DataManager.save_json(BOOKMARKS_FILE, self.bookmarks)
                list_widget.takeItem(list_widget.row(item))

        open_btn.clicked.connect(open_bookmark)
        delete_btn.clicked.connect(delete_bookmark)
        close_btn.clicked.connect(dlg.accept)

        btn_layout.addWidget(open_btn)
        btn_layout.addWidget(delete_btn)
        btn_layout.addWidget(close_btn)
        layout.addLayout(btn_layout)
        dlg.setLayout(layout)
        dlg.exec_()

    # -------------------- 历史 --------------------
    def show_history_dialog(self):
        if not self.history_data:
            QMessageBox.information(self, "历史", "暂无历史记录")
            return
        dlg = QDialog(self)
        dlg.setWindowTitle("历史记录")
        dlg.resize(600, 400)
        layout = QVBoxLayout()
        list_widget = QListWidget()
        for h in reversed(self.history_data):  # 最新的在前
            item = QListWidgetItem(f"{h['title']} - {h['url']}  ({h['time'][:16]})")
            item.setData(Qt.UserRole, h)
            list_widget.addItem(item)
        layout.addWidget(list_widget)

        btn_layout = QHBoxLayout()
        open_btn = QPushButton("打开选中")
        close_btn = QPushButton("关闭")

        def open_history():
            item = list_widget.currentItem()
            if item:
                h = item.data(Qt.UserRole)
                self.new_tab(h["url"], h["title"])
                dlg.accept()

        open_btn.clicked.connect(open_history)
        close_btn.clicked.connect(dlg.accept)
        btn_layout.addWidget(open_btn)
        btn_layout.addWidget(close_btn)
        layout.addLayout(btn_layout)
        dlg.setLayout(layout)
        dlg.exec_()

    def clear_history(self):
        self.history_data = []
        DataManager.save_json(HISTORY_FILE, self.history_data)
        QMessageBox.information(self, "历史", "历史记录已清除")

    # -------------------- 设置 --------------------
    def show_settings_dialog(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("偏好设置")
        layout = QFormLayout()

        home_edit = QLineEditWidget(self.config["home_url"])
        layout.addRow("首页地址:", home_edit)

        search_combo = QComboBox()
        search_combo.addItem("Bing", "https://www.bing.com/search?q={}")
        search_combo.addItem("Google", "https://www.google.com/search?q={}")
        search_combo.addItem("DuckDuckGo", "https://duckduckgo.com/?q={}")
        # 设置当前
        current = self.config["search_engine"]
        for i in range(search_combo.count()):
            if search_combo.itemData(i) == current:
                search_combo.setCurrentIndex(i)
                break
        layout.addRow("搜索引擎:", search_combo)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(lambda: self.save_settings(home_edit.text(), search_combo.currentData(), dlg))
        buttons.rejected.connect(dlg.reject)
        layout.addRow(buttons)

        dlg.setLayout(layout)
        dlg.exec_()

    def save_settings(self, home_url, search_engine, dlg):
        if home_url.strip():
            self.config["home_url"] = home_url.strip()
        self.config["search_engine"] = search_engine
        DataManager.save_json(CONFIG_FILE, self.config)
        dlg.accept()
        QMessageBox.information(self, "设置", "设置已保存")


# -------------------- 启动 --------------------
if __name__ == "__main__":
    app = QApplication(sys.argv)
    # 设置默认编码
    app.setApplicationName("crazy_browser")
    # 创建主窗口（非无痕）
    main_window = CrazyBrowser(is_private=False)
    main_window.show()
    sys.exit(app.exec_())