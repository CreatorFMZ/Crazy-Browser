# crazy_browser-2.5_r.2.py
# 一个用 Python + PyQt6 写的浏览器
# 版本 2.5_r.2：设置作为独立标签页 "crazy://setting"，支持书签、搜索引擎选择，DeepLost 链接到外部网站

import sys
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QLineEdit, QPushButton, QVBoxLayout, QWidget,
    QToolBar, QTabWidget, QLabel, QProgressBar, QComboBox, QMessageBox,
    QFormLayout, QRadioButton, QGroupBox, QCheckBox, QScrollArea,
    QListWidget, QHBoxLayout
)
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebEngineCore import QWebEngineProfile, QWebEnginePage
from PyQt6.QtCore import QUrl, QSettings
from PyQt6.QtGui import QAction


class BrowserTab(QWebEngineView):
    """浏览器标签页类"""
    def __init__(self, parent=None):
        super().__init__(parent)
        if hasattr(parent, 'update_progress'):
            self.loadProgress.connect(parent.update_progress)


class SettingsWidget(QWidget):
    """设置界面，作为独立标签页"""
    def __init__(self, parent=None, current_language="zh", version="2.5_r.2", translations=None):
        super().__init__(parent)
        self.parent_browser = parent
        self.current_language = current_language
        self.version = version
        self.trans = translations or {}
        self.setObjectName("settings_widget")

        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(20, 20, 20, 20)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        content = QWidget()
        layout = QFormLayout(content)

        # 首页设置
        homepage_group = QGroupBox(self.trans.get("homepage", "首页设置"))
        homepage_layout = QVBoxLayout()

        self.custom_home_check = QCheckBox(self.trans.get("use_custom_home", "使用自定义首页"))
        self.custom_home_check.setChecked(parent.home_url != "https://www.google.com")

        self.custom_home_url = QLineEdit()
        self.custom_home_url.setPlaceholderText("https://example.com")
        current_home = parent.home_url if parent.home_url != "https://www.google.com" else ""
        self.custom_home_url.setText(current_home)
        self.custom_home_url.setEnabled(self.custom_home_check.isChecked())

        self.custom_home_check.toggled.connect(self.custom_home_url.setEnabled)

        reset_btn = QPushButton(self.trans.get("reset_to_default", "恢复默认首页"))
        reset_btn.clicked.connect(self.reset_homepage)

        homepage_layout.addWidget(self.custom_home_check)
        homepage_layout.addWidget(self.custom_home_url)
        homepage_layout.addWidget(reset_btn)
        homepage_group.setLayout(homepage_layout)
        layout.addRow(homepage_group)

        # 主题设置
        theme_group = QGroupBox(self.trans.get("ui_theme", "界面主题"))
        theme_layout = QVBoxLayout()
        self.light_radio = QRadioButton(self.trans.get("light_mode", "浅色模式"))
        self.dark_radio = QRadioButton(self.trans.get("dark_mode", "深色模式"))
        self.light_radio.setChecked(True)
        theme_layout.addWidget(self.light_radio)
        theme_layout.addWidget(self.dark_radio)
        theme_group.setLayout(theme_layout)
        layout.addRow(theme_group)

        # 隐私设置
        privacy_group = QGroupBox(self.trans.get("privacy", "隐私设置"))
        privacy_layout = QVBoxLayout()
        self.persist_check = QCheckBox(self.trans.get("persist_history", "保留历史记录和登录状态"))
        self.persist_check.setChecked(True)
        privacy_layout.addWidget(self.persist_check)

        clear_btn = QPushButton(self.trans.get("clear_data", "清除浏览器数据"))
        clear_btn.clicked.connect(self.clear_browser_data)
        privacy_layout.addWidget(clear_btn)
        privacy_group.setLayout(privacy_layout)
        layout.addRow(privacy_group)

        # 语言设置
        lang_group = QGroupBox(self.trans.get("language", "语言"))
        lang_layout = QVBoxLayout()
        self.lang_zh = QRadioButton("中文 (简体)")
        self.lang_en = QRadioButton("English")
        if current_language == "en":
            self.lang_en.setChecked(True)
        else:
            self.lang_zh.setChecked(True)
        lang_layout.addWidget(self.lang_zh)
        lang_layout.addWidget(self.lang_en)
        lang_group.setLayout(lang_layout)
        layout.addRow(lang_group)

        # 搜索引擎选择
        search_engine_group = QGroupBox(self.trans.get("search_engine", "搜索引擎"))
        search_engine_layout = QVBoxLayout()
        self.search_engine_combo = QComboBox()
        self.search_engine_combo.addItems(["Google", "Bing", "Baidu"])
        current_engine = parent.settings.value("search_engine", "Google")
        self.search_engine_combo.setCurrentText(current_engine)
        search_engine_layout.addWidget(QLabel(self.trans.get("select_search_engine", "选择默认搜索引擎")))
        search_engine_layout.addWidget(self.search_engine_combo)
        search_engine_group.setLayout(search_engine_layout)
        layout.addRow(search_engine_group)

        # 书签管理
        bookmarks_group = QGroupBox(self.trans.get("bookmarks", "书签"))
        bookmarks_layout = QVBoxLayout()
        self.bookmarks_list = QListWidget()
        self.load_bookmarks()
        bookmarks_layout.addWidget(self.bookmarks_list)

        bookmark_buttons = QHBoxLayout()
        add_btn = QPushButton(self.trans.get("add_bookmark", "添加当前页面"))
        add_btn.clicked.connect(self.add_current_to_bookmarks)
        remove_btn = QPushButton(self.trans.get("remove_bookmark", "移除选中"))
        remove_btn.clicked.connect(self.remove_selected_bookmark)
        bookmark_buttons.addWidget(add_btn)
        bookmark_buttons.addWidget(remove_btn)
        bookmarks_layout.addLayout(bookmark_buttons)
        bookmarks_group.setLayout(bookmarks_layout)
        layout.addRow(bookmarks_group)

        # AI 集成（链接到外部网站）
        ai_group = QGroupBox(self.trans.get("ai_integration", "AI 集成"))
        ai_layout = QVBoxLayout()
        open_ai_btn = QPushButton(self.trans.get("open_deeplost", "打开 DeepLost X2"))
        open_ai_btn.clicked.connect(self.open_deeplost_ai)
        ai_layout.addWidget(open_ai_btn)
        ai_group.setLayout(ai_layout)
        layout.addRow(ai_group)

        # 版本信息 + 保存按钮
        version_label = QLabel(f"Crazy Browser {self.version} © Fantastic Star")
        version_label.setStyleSheet("color: gray;")
        layout.addRow(version_label)

        save_btn = QPushButton(self.trans.get("save_settings", "保存设置"))
        save_btn.clicked.connect(self.save_and_apply)
        layout.addRow(save_btn)

        scroll.setWidget(content)
        main_layout.addWidget(scroll)
        self.setLayout(main_layout)

    def load_bookmarks(self):
        bookmarks = self.parent_browser.settings.value("bookmarks", [])
        self.bookmarks_list.clear()
        for bm in bookmarks:
            self.bookmarks_list.addItem(bm)

    def add_current_to_bookmarks(self):
        current_view = self.parent_browser.current_view()
        if current_view and isinstance(current_view, QWebEngineView):
            url = current_view.url().toString()
            if url and url not in [self.bookmarks_list.item(i).text() for i in range(self.bookmarks_list.count())]:
                self.bookmarks_list.addItem(url)

    def remove_selected_bookmark(self):
        selected = self.bookmarks_list.selectedItems()
        if selected:
            for item in selected:
                self.bookmarks_list.takeItem(self.bookmarks_list.row(item))

    def reset_homepage(self):
        reply = QMessageBox.question(
            self,
            self.trans.get("confirm_reset_title", "确认恢复"),
            self.trans.get("confirm_reset_msg", "确定要将首页恢复为默认（Google）吗？"),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            self.custom_home_check.setChecked(False)
            self.custom_home_url.setText("")
            QMessageBox.information(self, "已恢复", "首页已恢复为默认设置")

    def clear_browser_data(self):
        parent = self.parent_browser
        t = parent.translations.get(parent.language, {})
        reply = QMessageBox.question(
            self,
            t.get("confirm_clear_title", "确认清除"),
            t.get("confirm_clear_msg", "确定要清除所有缓存、Cookie和历史记录吗？\n此操作不可撤销。"),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            profile = QWebEngineProfile.defaultProfile()
            profile.clearHttpCache()
            profile.clearAllVisitedLinks()
            profile.cookieStore().deleteAllCookies()
            QMessageBox.information(self, t.get("cleared_info_title", "操作完成"), t.get("cleared_info_msg", "浏览器数据已清除"))
            parent.refresh_all_tabs()

    def open_deeplost_ai(self):
        # 直接打开外部链接
        self.parent_browser.add_new_tab("https://deeplost.oneapp.dev/")

    def save_and_apply(self):
        parent = self.parent_browser

        # 保存首页设置
        custom_enabled = self.custom_home_check.isChecked()
        custom_url = self.custom_home_url.text().strip()
        parent.save_settings(custom_enabled, custom_url)

        # 保存搜索引擎
        parent.settings.setValue("search_engine", self.search_engine_combo.currentText())
        parent.search_engine = self.search_engine_combo.currentText()

        # 保存书签
        bookmarks = [self.bookmarks_list.item(i).text() for i in range(self.bookmarks_list.count())]
        parent.settings.setValue("bookmarks", bookmarks)

        # 应用主题
        if self.dark_radio.isChecked():
            parent.apply_dark_theme()
        else:
            parent.apply_light_theme()

        # 应用语言
        new_lang = "zh" if self.lang_zh.isChecked() else "en"
        if new_lang != parent.language:
            parent.set_language(new_lang)

        if not self.persist_check.isChecked():
            QMessageBox.information(
                self,
                parent.translations[parent.language]["app_title"],
                parent.translations[parent.language]["privacy_restart"]
            )

        QMessageBox.information(self, "保存成功", "设置已保存并应用。")


class CrazyBrowser(QMainWindow):
    def __init__(self):
        super().__init__()

        self.version = "2.5_r.2"
        self.language = "zh"

        self.settings = QSettings("FantasticStar", "CrazyBrowser")

        self.translations = {
            "zh": {
                "app_title": f"Crazy Browser {self.version} © Fantastic Star",
                "home_label": "首页",
                "new_tab": "+ 新标签页",
                "settings": "⚙ 设置",
                "device": " 设备: ",
                "placeholder": "输入网址或搜索内容...",
                "back_tip": "后退",
                "forward_tip": "前进",
                "reload_tip": "刷新",
                "home_tip": "主页",
                "ua_items": ["桌面模式", "手机模式"],
                "privacy_restart": "隐私设置将在浏览器重启后生效",
                "confirm_clear_title": "确认清除",
                "confirm_clear_msg": "确定要清除所有缓存、Cookie和历史记录吗？\n此操作不可撤销。",
                "cleared_info_title": "操作完成",
                "cleared_info_msg": "浏览器数据已清除",
                "settings_title": "设置",
                "ui_theme": "界面主题",
                "light_mode": "浅色模式",
                "dark_mode": "深色模式",
                "privacy": "隐私设置",
                "persist_history": "保留历史记录和登录状态",
                "clear_data": "清除浏览器数据",
                "language": "语言",
                "homepage": "首页设置",
                "use_custom_home": "使用自定义首页",
                "reset_to_default": "恢复默认首页",
                "confirm_reset_title": "确认恢复",
                "confirm_reset_msg": "确定要将首页恢复为默认（Google）吗？",
                "reset_done_title": "已恢复",
                "reset_done_msg": "首页已恢复为默认设置",
                "search_engine": "搜索引擎",
                "select_search_engine": "选择默认搜索引擎",
                "bookmarks": "书签",
                "add_bookmark": "添加当前页面",
                "remove_bookmark": "移除选中",
                "ai_integration": "AI 集成",
                "open_deeplost": "打开 DeepLost X2",
                "save_settings": "保存设置",
            },
            "en": {
                "app_title": f"Crazy Browser {self.version} © Fantastic Star",
                "home_label": "Home",
                "new_tab": "+ New Tab",
                "settings": "⚙ Settings",
                "device": " Device: ",
                "placeholder": "Enter URL or search...",
                "back_tip": "Back",
                "forward_tip": "Forward",
                "reload_tip": "Reload",
                "home_tip": "Home",
                "ua_items": ["Desktop", "Mobile"],
                "privacy_restart": "Privacy settings will take effect after restart",
                "confirm_clear_title": "Confirm Clear",
                "confirm_clear_msg": "Clear all cache, cookies and history?\nThis action cannot be undone.",
                "cleared_info_title": "Done",
                "cleared_info_msg": "Browser data cleared",
                "settings_title": "Settings",
                "ui_theme": "UI Theme",
                "light_mode": "Light Mode",
                "dark_mode": "Dark Mode",
                "privacy": "Privacy",
                "persist_history": "Keep history and login state",
                "clear_data": "Clear browser data",
                "language": "Language",
                "homepage": "Homepage",
                "use_custom_home": "Use custom homepage",
                "reset_to_default": "Reset to default homepage",
                "confirm_reset_title": "Confirm Reset",
                "confirm_reset_msg": "Reset homepage to default (Google)?",
                "reset_done_title": "Reset Complete",
                "reset_done_msg": "Homepage has been reset to default",
                "search_engine": "Search Engine",
                "select_search_engine": "Select default search engine",
                "bookmarks": "Bookmarks",
                "add_bookmark": "Add current page",
                "remove_bookmark": "Remove selected",
                "ai_integration": "AI Integration",
                "open_deeplost": "Open DeepLost X2",
                "save_settings": "Save Settings",
            }
        }

        self.home_url = "https://www.google.com"
        self.search_engine = self.settings.value("search_engine", "Google")
        self.load_settings()

        self.setWindowTitle(self.translations[self.language]["app_title"])
        self.resize(1280, 860)

        self.profile = QWebEngineProfile.defaultProfile()

        self.init_ui_components()
        self.setup_toolbar()
        self.setup_main_layout()

        self.add_new_tab(self.home_url, self.translations[self.language]["home_label"])

        self.apply_light_theme()

    def load_settings(self):
        custom_enabled = self.settings.value("custom_home/enabled", False, type=bool)
        custom_url = self.settings.value("custom_home/url", "", type=str)
        if custom_enabled and custom_url.strip():
            if not custom_url.startswith(("http://", "https://")):
                custom_url = "https://" + custom_url
            self.home_url = custom_url

    def save_settings(self, custom_home_enabled=False, custom_home_url=""):
        self.settings.setValue("custom_home/enabled", custom_home_enabled)
        cleaned_url = custom_home_url.strip()
        if custom_home_enabled and cleaned_url:
            if not cleaned_url.startswith(("http://", "https://")):
                cleaned_url = "https://" + cleaned_url
            self.home_url = cleaned_url
            self.settings.setValue("custom_home/url", cleaned_url)
        else:
            self.home_url = "https://www.google.com"
            self.settings.setValue("custom_home/url", "")
        self.settings.sync()

    def init_ui_components(self):
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.currentChanged.connect(self.update_ui_from_current_tab)

        self.url_bar = QLineEdit()
        self.url_bar.setPlaceholderText(self.translations[self.language]["placeholder"])
        self.url_bar.returnPressed.connect(self.navigate_to_url)

        self.progress_bar = QProgressBar()
        self.progress_bar.setMaximum(100)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setFixedHeight(3)
        self.progress_bar.setVisible(False)

        self.ua_combo = QComboBox()
        self.ua_combo.addItems(self.translations[self.language]["ua_items"])
        self.ua_combo.currentIndexChanged.connect(self.change_user_agent)

    def setup_toolbar(self):
        navbar = QToolBar("导航栏")
        navbar.setMovable(False)
        self.addToolBar(navbar)

        self.back_btn = QAction("←", self)
        self.back_btn.setToolTip(self.translations[self.language]["back_tip"])
        self.back_btn.triggered.connect(self.go_back)
        navbar.addAction(self.back_btn)

        self.forward_btn = QAction("→", self)
        self.forward_btn.setToolTip(self.translations[self.language]["forward_tip"])
        self.forward_btn.triggered.connect(self.go_forward)
        navbar.addAction(self.forward_btn)

        self.reload_btn = QAction("↻", self)
        self.reload_btn.setToolTip(self.translations[self.language]["reload_tip"])
        self.reload_btn.triggered.connect(self.reload_page)
        navbar.addAction(self.reload_btn)

        self.home_btn = QAction("🏠", self)
        self.home_btn.setToolTip(self.translations[self.language]["home_tip"])
        self.home_btn.triggered.connect(self.go_home)
        navbar.addAction(self.home_btn)

        navbar.addWidget(self.url_bar)

        self.ua_label = QLabel(self.translations[self.language]["device"])
        navbar.addWidget(self.ua_label)
        navbar.addWidget(self.ua_combo)

        self.new_tab_btn = QPushButton(self.translations[self.language]["new_tab"])
        self.new_tab_btn.clicked.connect(self.add_new_tab)
        navbar.addWidget(self.new_tab_btn)

        self.settings_btn = QPushButton(self.translations[self.language]["settings"])
        self.settings_btn.clicked.connect(self.show_settings)
        navbar.addWidget(self.settings_btn)

    def setup_main_layout(self):
        central = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self.progress_bar)
        layout.addWidget(self.tabs)
        central.setLayout(layout)
        self.setCentralWidget(central)

    def add_new_tab(self, url=None, title=None):
        if url is None or isinstance(url, bool):
            url = self.home_url
        if title is None:
            title = self.translations[self.language]["home_label"]

        qurl = QUrl(url)

        # 特殊内部页面
        if qurl.scheme() == "crazy" and qurl.host() == "setting":
            # 避免重复打开
            for i in range(self.tabs.count()):
                if isinstance(self.tabs.widget(i), SettingsWidget):
                    self.tabs.setCurrentIndex(i)
                    return
            settings_widget = SettingsWidget(self, self.language, self.version, self.translations.get(self.language, {}))
            index = self.tabs.addTab(settings_widget, self.translations[self.language]["settings_title"])
            self.tabs.setCurrentIndex(index)
            return

        # 普通网页
        page = QWebEnginePage(self.profile, self)
        view = BrowserTab(self)
        view.setPage(page)
        view.setUrl(qurl)

        view.titleChanged.connect(
            lambda t: self.tabs.setTabText(self.tabs.indexOf(view), (t or title)[:30])
        )
        view.urlChanged.connect(self.sync_url_bar)
        view.loadStarted.connect(self.page_load_started)
        view.loadFinished.connect(self.page_load_finished)

        index = self.tabs.addTab(view, title)
        self.tabs.setCurrentIndex(index)
        return view

    def page_load_started(self):
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(True)

    def page_load_finished(self, ok):
        self.progress_bar.setValue(100)
        if ok:
            self.progress_bar.setVisible(False)

        view = self.current_view()
        if view and isinstance(view, QWebEngineView):
            self.back_btn.setEnabled(view.history().canGoBack())
            self.forward_btn.setEnabled(view.history().canGoForward())

    def close_tab(self, index):
        if self.tabs.count() > 1:
            widget = self.tabs.widget(index)
            self.tabs.removeTab(index)
            widget.deleteLater()

    def current_view(self):
        return self.tabs.currentWidget()

    def go_back(self):
        view = self.current_view()
        if view and isinstance(view, QWebEngineView):
            view.back()

    def go_forward(self):
        view = self.current_view()
        if view and isinstance(view, QWebEngineView):
            view.forward()

    def reload_page(self):
        view = self.current_view()
        if view and isinstance(view, QWebEngineView):
            view.reload()

    def go_home(self):
        view = self.current_view()
        if view and isinstance(view, QWebEngineView):
            view.setUrl(QUrl(self.home_url))

    def navigate_to_url(self):
        text = self.url_bar.text().strip()
        if not text:
            return

        if text.startswith("crazy://"):
            self.add_new_tab(text)
            return

        if not text.startswith(("http://", "https://")):
            if "." in text:
                text = "https://" + text
            else:
                # 使用当前搜索引擎
                if self.search_engine == "Bing":
                    text = f"https://www.bing.com/search?q={text}"
                elif self.search_engine == "Baidu":
                    text = f"https://www.baidu.com/s?wd={text}"
                else:
                    text = f"https://www.google.com/search?q={text}"

        view = self.current_view()
        if view and isinstance(view, QWebEngineView):
            view.setUrl(QUrl(text))
        else:
            self.add_new_tab(text)

    def sync_url_bar(self, qurl):
        if self.tabs.currentWidget() == self.sender():
            self.url_bar.setText(qurl.toString())
            self.url_bar.setCursorPosition(0)

    def update_ui_from_current_tab(self, index):
        if index < 0:
            return

        widget = self.tabs.widget(index)
        if isinstance(widget, QWebEngineView):
            self.url_bar.setText(widget.url().toString())
            self.back_btn.setEnabled(widget.history().canGoBack())
            self.forward_btn.setEnabled(widget.history().canGoForward())
        else:
            # 设置页面
            self.url_bar.setText("crazy://setting")
            self.back_btn.setEnabled(False)
            self.forward_btn.setEnabled(False)

    def update_progress(self, value):
        self.progress_bar.setValue(value)

    def change_user_agent(self, index):
        ua = ""
        if index == 1:  # 手机模式
            ua = "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1"

        self.profile.setHttpUserAgent(ua)

        view = self.current_view()
        if view and isinstance(view, QWebEngineView) and view.url().toString():
            view.reload()

    def show_settings(self):
        self.add_new_tab("crazy://setting")

    def set_language(self, lang):
        if lang not in self.translations:
            return
        self.language = lang
        t = self.translations[self.language]

        self.setWindowTitle(t["app_title"])
        self.back_btn.setToolTip(t["back_tip"])
        self.forward_btn.setToolTip(t["forward_tip"])
        self.reload_btn.setToolTip(t["reload_tip"])
        self.home_btn.setToolTip(t["home_tip"])
        self.ua_label.setText(t["device"])
        self.new_tab_btn.setText(t["new_tab"])
        self.settings_btn.setText(t["settings"])
        self.url_bar.setPlaceholderText(t["placeholder"])
        self.ua_combo.clear()
        self.ua_combo.addItems(t["ua_items"])

        # 刷新设置页（如果打开）
        for i in range(self.tabs.count()):
            if isinstance(self.tabs.widget(i), SettingsWidget):
                self.tabs.removeTab(i)
                break

        for i in range(self.tabs.count()):
            if not self.tabs.tabText(i):
                self.tabs.setTabText(i, t["home_label"])

    def apply_dark_theme(self):
        dark_theme = """
            QMainWindow, QWidget { background: #1e1e1e; color: #e0e0e0; }
            QToolBar { background: #252525; border: none; padding: 4px; }
            QLineEdit { background: #333; color: #eee; border: 1px solid #555; border-radius: 3px; padding: 6px; }
            QTabWidget::pane { border: 1px solid #444; background: #222; }
            QTabBar::tab { background: #333; color: #ccc; padding: 8px 16px; margin-right: 2px; }
            QTabBar::tab:selected { background: #444; color: #fff; }
            QProgressBar { background: #333; border: none; }
            QProgressBar::chunk { background: #4CAF50; }
            QPushButton { background: #444; color: #eee; border: 1px solid #555; border-radius: 3px; padding: 6px 12px; }
            QPushButton:hover { background: #555; }
            QComboBox { background: #333; color: #eee; border: 1px solid #555; border-radius: 3px; padding: 4px; }
            QGroupBox { color: #ccc; }
            QCheckBox, QRadioButton { color: #eee; }
            QListWidget { background: #333; color: #eee; border: 1px solid #555; }
        """
        self.setStyleSheet(dark_theme)

    def apply_light_theme(self):
        self.setStyleSheet("")

    def refresh_all_tabs(self):
        for i in range(self.tabs.count()):
            widget = self.tabs.widget(i)
            if isinstance(widget, QWebEngineView) and widget.url().toString():
                widget.reload()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = CrazyBrowser()
    window.show()
    sys.exit(app.exec())
