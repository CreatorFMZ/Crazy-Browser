import sys
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QLineEdit, QPushButton,
    QVBoxLayout, QWidget, QToolBar, QTabWidget, QLabel,
    QProgressBar, QComboBox, QMessageBox
)
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebEngineCore import QWebEngineProfile, QWebEnginePage, QWebEngineSettings
from PyQt6.QtCore import QUrl, Qt
from PyQt6.QtGui import QAction, QIcon


class BrowserTab(QWebEngineView):
    """每个标签页是一个独立的 BrowserTab"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.loadProgress.connect(self.parent().update_progress if hasattr(self.parent(), 'update_progress') else lambda x: None)


class BrowserWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("FMZ Python Browser")
        self.setGeometry(80, 80, 1280, 860)

        # --------------------
        #   核心部件
        # --------------------
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.currentChanged.connect(self.update_ui_from_current_tab)

        self.url_bar = QLineEdit()
        self.url_bar.returnPressed.connect(self.navigate_to_url)

        self.progress_bar = QProgressBar()
        self.progress_bar.setMaximum(100)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setFixedHeight(3)
        self.progress_bar.setStyleSheet("QProgressBar::chunk { background: #4CAF50; }")

        # 用户代理切换
        self.ua_combo = QComboBox()
        self.ua_combo.addItems(["Desktop (default)", "Mobile (iPhone)", "Mobile (Android)"])
        self.ua_combo.currentIndexChanged.connect(self.change_user_agent)

        # 首页（简单版）
        self.home_url = "https://www.google.com"

        # --------------------
        #   工具栏
        # --------------------
        navbar = QToolBar("导航")
        navbar.setMovable(False)
        self.addToolBar(navbar)

        back_act = QAction("←", self)
        back_act.triggered.connect(self.current_browser_back)
        navbar.addAction(back_act)

        forward_act = QAction("→", self)
        forward_act.triggered.connect(self.current_browser_forward)
        navbar.addAction(forward_act)

        reload_act = QAction("↻", self)
        reload_act.triggered.connect(self.current_browser_reload)
        navbar.addAction(reload_act)

        home_act = QAction("🏠", self)
        home_act.triggered.connect(self.go_home)
        navbar.addAction(home_act)

        navbar.addWidget(self.url_bar)
        navbar.addWidget(QLabel("UA:"))
        navbar.addWidget(self.ua_combo)

        # 新标签页按钮
        new_tab_btn = QPushButton("+")
        new_tab_btn.setFixedWidth(40)
        new_tab_btn.clicked.connect(self.add_new_tab)
        navbar.addWidget(new_tab_btn)

        # --------------------
        #   主布局
        # --------------------
        central_widget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self.progress_bar)
        layout.addWidget(self.tabs)
        central_widget.setLayout(layout)
        self.setCentralWidget(central_widget)

        # 初始化第一个标签页
        self.add_new_tab(self.home_url, "首页")

    def add_new_tab(self, url=None, label="新标签页"):
        if url is None:
            url = self.home_url

        browser = BrowserTab(self)
        browser.setUrl(QUrl(url))

        # 连接信号
        browser.titleChanged.connect(lambda title: self.tabs.setTabText(self.tabs.indexOf(browser), title[:40] or "无标题"))
        browser.iconChanged.connect(lambda icon: self.tabs.setTabIcon(self.tabs.indexOf(browser), icon))
        browser.urlChanged.connect(self.sync_url_bar)
        browser.loadStarted.connect(lambda: self.progress_bar.setValue(0))
        browser.loadFinished.connect(lambda ok: self.progress_bar.setValue(100 if ok else 0))

        i = self.tabs.addTab(browser, label)
        self.tabs.setCurrentIndex(i)

    def close_tab(self, index):
        if self.tabs.count() > 1:
            widget = self.tabs.widget(index)
            self.tabs.removeTab(index)
            widget.deleteLater()

    def current_browser(self):
        return self.tabs.currentWidget()

    def current_browser_back(self):
        b = self.current_browser()
        if b:
            b.back()

    def current_browser_forward(self):
        b = self.current_browser()
        if b:
            b.forward()

    def current_browser_reload(self):
        b = self.current_browser()
        if b:
            b.reload()

    def go_home(self):
        b = self.current_browser()
        if b:
            b.setUrl(QUrl(self.home_url))

    def navigate_to_url(self):
        text = self.url_bar.text().strip()
        if not text:
            return
        if not text.startswith(("http://", "https://")):
            text = "https://" + text
        b = self.current_browser()
        if b:
            b.setUrl(QUrl(text))

    def sync_url_bar(self, qurl):
        if self.tabs.currentWidget() == self.sender():
            self.url_bar.setText(qurl.toString())
            self.url_bar.setCursorPosition(0)

    def update_ui_from_current_tab(self, index):
        if index < 0:
            return
        b = self.tabs.widget(index)
        if b:
            self.url_bar.setText(b.url().toString())

    def update_progress(self, progress):
        self.progress_bar.setValue(progress)

    def change_user_agent(self, index):
        profile = QWebEngineProfile.defaultProfile()

        if index == 0:  # Desktop
            ua = ""
        elif index == 1:  # iPhone
            ua = "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1"
        elif index == 2:  # Android
            ua = "Mozilla/5.0 (Linux; Android 12; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36"
        else:
            ua = ""

        profile.setHttpUserAgent(ua)
        # 通知当前所有标签页更新（最简单粗暴的方式）
        for i in range(self.tabs.count()):
            view = self.tabs.widget(i)
            if view:
                # 重新加载以应用新 UA（也可以只在新建标签时设置）
                if view.url().toString() != "":
                    view.reload()


if __name__ == "__main__":
    app = QApplication(sys.argv)

    # 可选：全局暗色尝试（后续再完善）
    # app.setStyleSheet("QWidget { background: #222; color: #eee; }")

    window = BrowserWindow()
    window.show()
    sys.exit(app.exec())