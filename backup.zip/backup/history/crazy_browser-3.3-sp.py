import sys
import json
import os
from datetime import datetime
from urllib.parse import urlparse, parse_qs, quote
from PyQt5.QtCore import QUrl, Qt, QTimer
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QTabWidget, QToolBar, QLineEdit,
    QPushButton, QStatusBar, QVBoxLayout, QHBoxLayout,
    QMenu, QAction, QDialog, QListWidget, QListWidgetItem,
    QMessageBox, QComboBox, QDialogButtonBox, QFormLayout,
    QFileDialog, QCheckBox
)
from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEngineProfile, QWebEnginePage
from PyQt5.QtGui import QKeySequence, QCloseEvent

# -------------------- Constants --------------------
CONFIG_FILE = "crazy_browser_config.json"
BOOKMARKS_FILE = "crazy_browser_bookmarks.json"
HISTORY_FILE = "crazy_browser_history.json"
NEW_TAB_URL = "crazy://newtab"
SETTINGS_URL = "crazy://settings"

# -------------------- 白名单（国内网站） --------------------
ALLOWED_DOMAINS = [
    "baidu.com", "qq.com", "sina.com.cn", "weibo.com", "taobao.com",
    "jd.com", "163.com", "sohu.com", "360.cn", "xiaomi.com",
    "alibaba.com", "tencent.com", "zhihu.com", "bilibili.com",
    "douban.com", "csdn.net", "oschina.net", "cnblogs.com",
]
ENABLE_BLOCK = True  # 可全局开关

# -------------------- Data Manager --------------------
class DataManager:
    @staticmethod
    def load_json(file, default):
        try:
            with open(file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return default

    @staticmethod
    def save_json(file, data):
        with open(file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

# -------------------- Custom Web Page (handles crazy:// + block) --------------------
class CrazyWebPage(QWebEnginePage):
    def __init__(self, view, parent=None):
        super().__init__(parent)
        self.view = view

    def acceptNavigationRequest(self, url, navigationType, isMainFrame):
        url_str = url.toString()

        # 1. 处理内部 crazy:// 协议
        if url_str.startswith("crazy://"):
            main = self.view.get_main_window()
            if not main:
                return False

            if url_str == NEW_TAB_URL:
                self.view.load_new_tab_page()
                return False

            elif url_str.startswith(SETTINGS_URL):
                parsed = urlparse(url_str)
                params = parse_qs(parsed.query)

                if 'save' in params:
                    home = params.get('home', [main.config.get('home_url', '')])[0]
                    engine = params.get('engine', [main.config.get('search_engine', '')])[0]
                    clear_history = params.get('clear_history', ['false'])[0].lower() == 'true'

                    if home.strip():
                        main.config['home_url'] = home.strip()
                    if engine.strip():
                        main.config['search_engine'] = engine.strip()
                    main.config['clear_history_on_close'] = clear_history
                    DataManager.save_json(CONFIG_FILE, main.config)

                    self.view.load_settings_page()
                else:
                    self.view.load_settings_page()
                return False

            else:
                return False

        # 2. 白名单拦截（仅对主框架请求生效）
        if isMainFrame and ENABLE_BLOCK:
            if not self.is_allowed(url):
                original_url = url.toString()
                block_html = self.generate_block_html(original_url)
                QTimer.singleShot(0, lambda: self.view.setHtml(
                    block_html,
                    baseUrl=QUrl("crazy://block?url=" + quote(original_url, safe=''))
                ))
                return False

        return super().acceptNavigationRequest(url, navigationType, isMainFrame)

    def is_allowed(self, url):
        host = url.host()
        if not host:
            return True
        # 允许 .cn 域名、本地地址
        if host.endswith('.cn'):
            return True
        if host in ('localhost', '127.0.0.1', '::1'):
            return True
        for domain in ALLOWED_DOMAINS:
            if host == domain or host.endswith('.' + domain):
                return True
        return False

    def generate_block_html(self, original_url):
        # 获取首页地址用于“前往首页”链接
        home_url = "https://bing.com"
        try:
            main = self.view.get_main_window()
            if main and 'home_url' in main.config:
                home_url = main.config['home_url']
        except:
            pass

        return f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>访问被拦截</title>
            <style>
                body {{
                    margin: 0;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    background: #1a1a1a;
                    font-family: Arial, sans-serif;
                }}
                .block-container {{
                    text-align: center;
                    padding: 40px;
                    border-radius: 20px;
                    background: #2d2d2d;
                    box-shadow: 0 10px 40px rgba(0,0,0,0.8);
                }}
                .block-title {{
                    font-size: 80px;
                    font-weight: bold;
                    color: #ff0000;
                    text-shadow: 0 0 20px #ff0000, 0 0 40px #ff0000;
                    margin-bottom: 20px;
                }}
                .block-sub {{
                    font-size: 24px;
                    color: #cccccc;
                    margin-bottom: 30px;
                }}
                .block-url {{
                    font-size: 18px;
                    color: #66ccff;
                    background: #1a1a1a;
                    padding: 12px 24px;
                    border-radius: 10px;
                    word-break: break-all;
                    display: inline-block;
                    max-width: 80%;
                }}
                .block-note {{
                    margin-top: 30px;
                    color: #888888;
                    font-size: 14px;
                }}
                a {{
                    color: #66ccff;
                    text-decoration: none;
                }}
            </style>
        </head>
        <body>
            <div class="block-container">
                <div class="block-title">🚫 Access Denied</div>
                <div class="block-sub">该网站不在允许列表内，访问被拒绝</div>
                <div class="block-url">被拦截的网址：<br>{original_url}</div>
                <div class="block-note">
                    <a href="javascript:history.back()">返回上一页</a> &nbsp;|&nbsp;
                    <a href="{home_url}">前往首页</a>
                </div>
            </div>
        </body>
        </html>
        """

# -------------------- Custom Web View --------------------
class CrazyWebView(QWebEngineView):
    def __init__(self, parent=None, is_private=False):
        super().__init__(parent)
        self.is_private = is_private
        self.download_progress = 0

        self.setPage(CrazyWebPage(self, self))

        # 无痕模式设置
        if is_private:
            profile = self.page().profile()
            profile.setPersistentStoragePolicy(QWebEngineProfile.MemoryStorage)
            profile.setPersistentCookiesPolicy(QWebEngineProfile.NoPersistentCookies)

        self.page().profile().downloadRequested.connect(self.handle_download)

        # 右键菜单（增加开发者工具）
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.open_context_menu)

    def get_main_window(self):
        p = self.parent()
        while p:
            if isinstance(p, CrazyBrowser):
                return p
            p = p.parent()
        return None

    def createWindow(self, window_type):
        # 新窗口继承当前窗口的无痕状态
        main = self.get_main_window()
        if main:
            new_view = CrazyWebView(parent=None, is_private=main.is_private)
            index = main.tab_widget.addTab(new_view, "New Tab")
            main.tab_widget.setCurrentIndex(index)
            new_view.titleChanged.connect(lambda t: main.update_tab_title(new_view, t))
            new_view.urlChanged.connect(lambda qurl: main.update_url_bar(qurl, new_view))
            new_view.loadProgress.connect(lambda p: main.update_status(p, new_view))
            new_view.loadFinished.connect(lambda ok: main.record_history(new_view))
            return new_view
        return super().createWindow(window_type)

    def setUrl(self, url):
        super().setUrl(url)

    # ---------- 内置页面（来自 3.3） ----------
    def load_new_tab_page(self):
        main = self.get_main_window()
        search_engine = main.config.get("search_engine", "https://www.bing.com/search?q={}") if main else "https://www.bing.com/search?q={}"

        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>New Tab</title>
            <style>
                body {{
                    margin: 0;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    background: #f0f0f0;
                    font-family: Arial, sans-serif;
                }}
                .container {{
                    text-align: center;
                    padding: 40px;
                    background: #ffffff;
                    border-radius: 20px;
                    box-shadow: 0 10px 40px rgba(0,0,0,0.1);
                }}
                h1 {{
                    color: #333;
                    font-size: 36px;
                    margin-bottom: 30px;
                }}
                .search-box {{
                    display: flex;
                    justify-content: center;
                    gap: 10px;
                }}
                #search-input {{
                    width: 400px;
                    padding: 14px 20px;
                    font-size: 18px;
                    border: 1px solid #ccc;
                    border-radius: 30px;
                    outline: none;
                    background: #fafafa;
                    color: #333;
                }}
                #search-btn {{
                    padding: 14px 28px;
                    font-size: 18px;
                    border: none;
                    border-radius: 30px;
                    background: #4a90d9;
                    color: #fff;
                    cursor: pointer;
                    transition: background 0.2s;
                }}
                #search-btn:hover {{
                    background: #5a9ef0;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>🌐 Crazy Browser</h1>
                <div class="search-box">
                    <input id="search-input" type="text" placeholder="Search or enter address..." autofocus>
                    <button id="search-btn">Search</button>
                </div>
            </div>
            <script>
                const input = document.getElementById('search-input');
                const btn = document.getElementById('search-btn');
                function doSearch() {{
                    const q = input.value.trim();
                    if (!q) return;
                    const engine = '{search_engine}';
                    const url = engine.replace('{{}}', encodeURIComponent(q));
                    window.location.href = url;
                }}
                btn.addEventListener('click', doSearch);
                input.addEventListener('keydown', (e) => {{
                    if (e.key === 'Enter') doSearch();
                }});
            </script>
        </body>
        </html>
        """
        self.setHtml(html, baseUrl=QUrl(NEW_TAB_URL))

    def load_settings_page(self):
        main = self.get_main_window()
        if not main:
            return
        config = main.config
        home_url = config.get("home_url", "")
        search_engine = config.get("search_engine", "https://www.bing.com/search?q={}")
        clear_history = config.get("clear_history_on_close", False)

        presets = {
            "Bing": "https://www.bing.com/search?q={}",
            "Google": "https://www.google.com/search?q={}",
            "DuckDuckGo": "https://duckduckgo.com/?q={}"
        }
        engine_options = ""
        for label, url_template in presets.items():
            selected = "selected" if url_template == search_engine else ""
            engine_options += f'<option value="{url_template}" {selected}>{label}</option>'
        if search_engine not in presets.values():
            engine_options += f'<option value="custom" selected>Custom</option>'
        else:
            engine_options += f'<option value="custom">Custom</option>'

        checked = "checked" if clear_history else ""

        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Settings</title>
            <style>
                body {{
                    margin: 0;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    min-height: 100vh;
                    background: #f0f0f0;
                    font-family: Arial, sans-serif;
                }}
                .container {{
                    text-align: left;
                    padding: 40px;
                    background: #ffffff;
                    border-radius: 20px;
                    box-shadow: 0 10px 40px rgba(0,0,0,0.1);
                    color: #333;
                    width: 450px;
                }}
                h1 {{
                    color: #333;
                    font-size: 32px;
                    margin-bottom: 25px;
                    text-align: center;
                }}
                .field {{
                    display: flex;
                    flex-direction: column;
                    margin: 12px 0;
                }}
                .field label {{
                    font-size: 16px;
                    margin-bottom: 4px;
                }}
                .field input, .field select {{
                    padding: 8px 12px;
                    font-size: 15px;
                    border: 1px solid #ccc;
                    border-radius: 8px;
                    background: #fafafa;
                    color: #333;
                    outline: none;
                }}
                .field input:focus, .field select:focus {{
                    border-color: #4a90d9;
                }}
                .field-checkbox {{
                    flex-direction: row;
                    align-items: center;
                    gap: 10px;
                }}
                .field-checkbox input {{
                    width: 18px;
                    height: 18px;
                    margin: 0;
                }}
                #custom-engine-container {{
                    margin-top: 6px;
                }}
                #save-btn {{
                    margin-top: 20px;
                    padding: 12px 32px;
                    font-size: 18px;
                    border: none;
                    border-radius: 30px;
                    background: #4a90d9;
                    color: #fff;
                    cursor: pointer;
                    transition: background 0.2s;
                    width: 100%;
                }}
                #save-btn:hover {{
                    background: #5a9ef0;
                }}
                .footer {{
                    margin-top: 30px;
                    text-align: center;
                    font-size: 14px;
                    color: #777;
                    border-top: 1px solid #eee;
                    padding-top: 20px;
                }}
                .footer a {{
                    color: #4a90d9;
                    text-decoration: none;
                }}
                .footer a:hover {{
                    text-decoration: underline;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>Settings</h1>
                <div class="field">
                    <label>Home page</label>
                    <input id="home-input" type="text" value="{home_url}" placeholder="https://example.com">
                </div>
                <div class="field">
                    <label>Default Search Engine</label>
                    <select id="engine-select">
                        {engine_options}
                    </select>
                    <div id="custom-engine-container" style="display: {'block' if search_engine not in presets.values() else 'none'};">
                        <input id="custom-engine-input" type="text" value="{search_engine if search_engine not in presets.values() else ''}" placeholder="Custom search URL (use {{}} as query placeholder)">
                    </div>
                </div>
                <div class="field field-checkbox">
                    <label for="clear-check">Clear history on close</label>
                    <input id="clear-check" type="checkbox" {checked}>
                </div>
                <button id="save-btn">Save</button>
                <div class="footer">
                    <div style="font-weight: bold; font-size: 16px;">Crazy Browser</div>
                    <div>© <a href="https://fshp.oneapp.dev" target="_blank">Fantastic Star</a> 2026, all rights reserved.</div>
                </div>
            <script>
                const engineSelect = document.getElementById('engine-select');
                const customContainer = document.getElementById('custom-engine-container');
                const customInput = document.getElementById('custom-engine-input');

                engineSelect.addEventListener('change', function() {{
                    if (this.value === 'custom') {{
                        customContainer.style.display = 'block';
                        customInput.focus();
                    }} else {{
                        customContainer.style.display = 'none';
                    }}
                }});

                document.getElementById('save-btn').addEventListener('click', function() {{
                    const home = document.getElementById('home-input').value.trim();
                    let engine = engineSelect.value;
                    if (engine === 'custom') {{
                        engine = customInput.value.trim();
                        if (!engine) {{
                            alert('Please enter a custom search URL.');
                            return;
                        }}
                        if (!engine.includes('{{}}')) {{
                            alert('Custom search URL must contain "{{}}" as placeholder for the query.');
                            return;
                        }}
                    }}
                    const clearHistory = document.getElementById('clear-check').checked;
                    const params = new URLSearchParams({{
                        save: '1',
                        home: home,
                        engine: engine,
                        clear_history: clearHistory ? 'true' : 'false'
                    }});
                    window.location.href = 'crazy://settings?' + params.toString();
                }});
            </script>
        </body>
        </html>
        """
        self.setHtml(html, baseUrl=QUrl(SETTINGS_URL))

    # ---------- 下载处理 ----------
    def handle_download(self, download):
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Save File", download.suggestedFileName()
        )
        if file_path:
            download.setPath(file_path)
            download.accept()
            download.downloadProgress.connect(
                lambda r, t: self.parent().parent().statusBar().showMessage(
                    f"Downloading: {download.suggestedFileName()} {int(r/t*100)}%"
                ) if self.parent() else None
            )
            download.finished.connect(
                lambda: self.parent().parent().statusBar().showMessage(
                    f"Download complete: {os.path.basename(file_path)}"
                ) if self.parent() else None
            )

    # ---------- 右键菜单（含开发者工具） ----------
    def open_context_menu(self, pos):
        menu = self.page().createStandardContextMenu()
        menu.addSeparator()
        dev_action = QAction("开发者工具 (F12)", self)
        dev_action.triggered.connect(lambda: self.page().triggerAction(QWebEnginePage.InspectElement))
        menu.addAction(dev_action)
        menu.exec_(self.mapToGlobal(pos))

# -------------------- Main Browser Window --------------------
class CrazyBrowser(QMainWindow):
    def __init__(self, is_private=False, parent=None):
        super().__init__(parent)
        self.is_private = is_private
        self.setWindowTitle("crazy_browser" + (" (无痕)" if is_private else ""))
        self.setGeometry(100, 100, 1200, 800)

        self.config = DataManager.load_json(CONFIG_FILE, {
            "home_url": "https://creativesearch.pages.dev",
            "search_engine": "https://www.bing.com/search?q={}",
            "clear_history_on_close": False
        })
        self.bookmarks = DataManager.load_json(BOOKMARKS_FILE, [])
        self.history_data = DataManager.load_json(HISTORY_FILE, [])

        self.tab_widget = QTabWidget()
        self.tab_widget.setTabsClosable(True)
        self.tab_widget.tabCloseRequested.connect(self.close_tab)
        self.tab_widget.currentChanged.connect(self.on_tab_changed)
        self.setCentralWidget(self.tab_widget)

        self.create_toolbar()
        self.create_menu_bar()

        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)

        # 浅色主题（与 3.3 一致）
        self.apply_light_theme()

        self.new_tab(self.config["home_url"])

        self.setup_shortcuts()

    def apply_light_theme(self):
        style = """
            QMainWindow, QDialog {
                background-color: #f0f0f0;
                color: #000000;
            }
            QToolBar, QStatusBar, QMenuBar, QMenu {
                background-color: #e0e0e0;
                color: #000000;
            }
            QLineEdit, QComboBox, QListWidget {
                background-color: #ffffff;
                color: #000000;
                border: 1px solid #aaa;
            }
            QPushButton {
                background-color: #4a90d9;
                color: #ffffff;
                border: none;
                padding: 6px 12px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #5a9ef0;
            }
            QTabWidget::pane {
                border: 1px solid #aaa;
            }
            QTabBar::tab {
                background-color: #e0e0e0;
                color: #000000;
                padding: 8px 12px;
            }
            QTabBar::tab:selected {
                background-color: #4a90d9;
                color: #ffffff;
            }
        """
        self.setStyleSheet(style)

    def create_toolbar(self):
        nav_bar = QToolBar("Navigation")
        self.addToolBar(nav_bar)

        back_btn = QPushButton("←")
        back_btn.clicked.connect(lambda: self.current_view().back())
        nav_bar.addWidget(back_btn)

        forward_btn = QPushButton("→")
        forward_btn.clicked.connect(lambda: self.current_view().forward())
        nav_bar.addWidget(forward_btn)

        reload_btn = QPushButton("↻")
        reload_btn.clicked.connect(lambda: self.current_view().reload())
        nav_bar.addWidget(reload_btn)

        stop_btn = QPushButton("✕")
        stop_btn.clicked.connect(lambda: self.current_view().stop())
        nav_bar.addWidget(stop_btn)

        self.url_bar = QLineEdit()
        self.url_bar.returnPressed.connect(self.navigate_to_url)
        nav_bar.addWidget(self.url_bar)

        home_btn = QPushButton("🏠")
        home_btn.clicked.connect(self.go_home)
        nav_bar.addWidget(home_btn)

        new_tab_btn = QPushButton("+")
        new_tab_btn.clicked.connect(lambda: self.new_tab(None))
        nav_bar.addWidget(new_tab_btn)

        bookmark_btn = QPushButton("☆")
        bookmark_btn.setToolTip("Add bookmark")
        bookmark_btn.clicked.connect(self.add_current_bookmark)
        nav_bar.addWidget(bookmark_btn)

    def create_menu_bar(self):
        menubar = self.menuBar()

        # File menu
        file_menu = menubar.addMenu("File")
        new_tab_action = QAction("New Tab (Ctrl+T)", self)
        new_tab_action.triggered.connect(lambda: self.new_tab(None))
        file_menu.addAction(new_tab_action)

        new_window_action = QAction("New Window", self)
        new_window_action.triggered.connect(self.new_window)
        file_menu.addAction(new_window_action)

        new_private_action = QAction("New Private Window (Ctrl+Shift+N)", self)
        new_private_action.triggered.connect(self.new_private_window)
        file_menu.addAction(new_private_action)

        file_menu.addSeparator()
        close_tab_action = QAction("Close Tab (Ctrl+W)", self)
        close_tab_action.triggered.connect(lambda: self.close_tab(self.tab_widget.currentIndex()))
        file_menu.addAction(close_tab_action)

        # History menu
        history_menu = menubar.addMenu("History")
        show_history_action = QAction("Show All History", self)
        show_history_action.triggered.connect(self.show_history_dialog)
        history_menu.addAction(show_history_action)

        clear_history_action = QAction("Clear History", self)
        clear_history_action.triggered.connect(self.clear_history)
        history_menu.addAction(clear_history_action)

        # Bookmarks menu
        bookmark_menu = menubar.addMenu("Bookmarks")
        add_bookmark_action = QAction("Add Current Page", self)
        add_bookmark_action.triggered.connect(self.add_current_bookmark)
        bookmark_menu.addAction(add_bookmark_action)

        show_bookmarks_action = QAction("Manage Bookmarks", self)
        show_bookmarks_action.triggered.connect(self.show_bookmarks_dialog)
        bookmark_menu.addAction(show_bookmarks_action)

        # Settings – direct action (opens built-in settings page)
        settings_action = QAction("Settings", self)
        settings_action.triggered.connect(self.open_settings_tab)
        menubar.addAction(settings_action)

        # Developer menu
        dev_menu = menubar.addMenu("Developer")
        dev_action = QAction("Developer Tools (F12)", self)
        dev_action.triggered.connect(lambda: self.current_view().page().triggerAction(QWebEnginePage.InspectElement))
        dev_menu.addAction(dev_action)

    def setup_shortcuts(self):
        new_tab_shortcut = QAction(self)
        new_tab_shortcut.setShortcut(QKeySequence("Ctrl+T"))
        new_tab_shortcut.triggered.connect(lambda: self.new_tab(None))
        self.addAction(new_tab_shortcut)

        close_tab_shortcut = QAction(self)
        close_tab_shortcut.setShortcut(QKeySequence("Ctrl+W"))
        close_tab_shortcut.triggered.connect(lambda: self.close_tab(self.tab_widget.currentIndex()))
        self.addAction(close_tab_shortcut)

        private_shortcut = QAction(self)
        private_shortcut.setShortcut(QKeySequence("Ctrl+Shift+N"))
        private_shortcut.triggered.connect(self.new_private_window)
        self.addAction(private_shortcut)

        dev_shortcut = QAction(self)
        dev_shortcut.setShortcut(QKeySequence("F12"))
        dev_shortcut.triggered.connect(lambda: self.current_view().page().triggerAction(QWebEnginePage.InspectElement))
        self.addAction(dev_shortcut)

    # -------------------- Tab Management --------------------
    def new_tab(self, url=None, title="New Tab"):
        view = CrazyWebView(self, is_private=self.is_private)

        if url is None:
            view.load_new_tab_page()
            display_title = "New Tab"
        elif url == NEW_TAB_URL:
            view.load_new_tab_page()
            display_title = "New Tab"
        elif url == SETTINGS_URL:
            view.load_settings_page()
            display_title = "Settings"
        else:
            view.setUrl(QUrl(url))
            display_title = title

        index = self.tab_widget.addTab(view, display_title)
        self.tab_widget.setCurrentIndex(index)

        view.urlChanged.connect(lambda qurl: self.update_url_bar(qurl, view))
        view.titleChanged.connect(lambda t: self.update_tab_title(view, t))
        view.loadProgress.connect(lambda p: self.update_status(p, view))
        view.loadFinished.connect(lambda ok: self.record_history(view))
        return view

    def close_tab(self, index):
        if self.tab_widget.count() > 1:
            self.tab_widget.removeTab(index)
        else:
            self.close()

    def current_view(self):
        return self.tab_widget.currentWidget()

    def on_tab_changed(self, index):
        if index >= 0:
            view = self.tab_widget.widget(index)
            if view:
                self.update_url_bar(view.url(), view)
                self.setWindowTitle("crazy_browser - " + view.title())

    def update_tab_title(self, view, title):
        idx = self.tab_widget.indexOf(view)
        if idx >= 0:
            short = title[:20] + "..." if len(title) > 20 else title
            self.tab_widget.setTabText(idx, short)
            if view == self.current_view():
                self.setWindowTitle("crazy_browser - " + title)

    # -------------------- Navigation --------------------
    def navigate_to_url(self):
        text = self.url_bar.text().strip()
        if not text:
            return
        if "." in text or text.startswith("chrome://") or text.startswith("http") or text.startswith("crazy://"):
            if not text.startswith("http") and not text.startswith("chrome://") and not text.startswith("crazy://"):
                text = "http://" + text
            url = QUrl.fromUserInput(text)
        else:
            search_url = self.config["search_engine"].format(text)
            url = QUrl(search_url)
        self.current_view().setUrl(url)

    def go_home(self):
        self.current_view().setUrl(QUrl(self.config["home_url"]))

    def update_url_bar(self, url, view):
        if view == self.current_view():
            self.url_bar.setText(url.toString())

    def update_status(self, progress, view):
        if view == self.current_view():
            self.status_bar.showMessage(f"Loading {progress}%")

    def record_history(self, view):
        # 无痕模式不记录
        if view.is_private:
            return
        if view.url().isValid():
            url_str = view.url().toString()
            if not self.history_data or self.history_data[-1]["url"] != url_str:
                self.history_data.append({
                    "url": url_str,
                    "title": view.title(),
                    "time": datetime.now().isoformat()
                })
                DataManager.save_json(HISTORY_FILE, self.history_data)

    # -------------------- Window Management --------------------
    def new_window(self):
        win = CrazyBrowser(is_private=False)
        win.show()

    def new_private_window(self):
        win = CrazyBrowser(is_private=True)
        win.show()

    # -------------------- Bookmarks --------------------
    def add_current_bookmark(self):
        view = self.current_view()
        url = view.url().toString()
        title = view.title()
        if not url or url == "about:blank" or url.startswith("crazy://"):
            return
        for b in self.bookmarks:
            if b["url"] == url:
                QMessageBox.information(self, "Bookmark", "Already bookmarked.")
                return
        self.bookmarks.append({"url": url, "title": title})
        DataManager.save_json(BOOKMARKS_FILE, self.bookmarks)
        QMessageBox.information(self, "Bookmark", f"Added: {title}")

    def show_bookmarks_dialog(self):
        if not self.bookmarks:
            QMessageBox.information(self, "Bookmarks", "No bookmarks.")
            return
        dlg = QDialog(self)
        dlg.setWindowTitle("Manage Bookmarks")
        dlg.resize(500, 400)
        layout = QVBoxLayout()
        list_widget = QListWidget()
        for b in self.bookmarks:
            item = QListWidgetItem(f"{b['title']} - {b['url']}")
            item.setData(Qt.UserRole, b)
            list_widget.addItem(item)
        layout.addWidget(list_widget)

        btn_layout = QHBoxLayout()
        open_btn = QPushButton("Open")
        delete_btn = QPushButton("Delete")
        close_btn = QPushButton("Close")

        def open_bookmark():
            item = list_widget.currentItem()
            if item:
                b = item.data(Qt.UserRole)
                self.new_tab(b["url"], b["title"])
                dlg.accept()

        def delete_bookmark():
            item = list_widget.currentItem()
            if item:
                b = item.data(Qt.UserRole)
                self.bookmarks = [x for x in self.bookmarks if x["url"] != b["url"]]
                DataManager.save_json(BOOKMARKS_FILE, self.bookmarks)
                list_widget.takeItem(list_widget.row(item))

        open_btn.clicked.connect(open_bookmark)
        delete_btn.clicked.connect(delete_bookmark)
        close_btn.clicked.connect(dlg.accept)

        btn_layout.addWidget(open_btn)
        btn_layout.addWidget(delete_btn)
        btn_layout.addWidget(close_btn)
        layout.addLayout(btn_layout)
        dlg.setLayout(layout)
        dlg.exec_()

    # -------------------- History --------------------
    def show_history_dialog(self):
        if not self.history_data:
            QMessageBox.information(self, "History", "No history.")
            return
        dlg = QDialog(self)
        dlg.setWindowTitle("History")
        dlg.resize(600, 400)
        layout = QVBoxLayout()
        list_widget = QListWidget()
        for h in reversed(self.history_data):
            item = QListWidgetItem(f"{h['title']} - {h['url']}  ({h['time'][:16]})")
            item.setData(Qt.UserRole, h)
            list_widget.addItem(item)
        layout.addWidget(list_widget)

        btn_layout = QHBoxLayout()
        open_btn = QPushButton("Open")
        close_btn = QPushButton("Close")

        def open_history():
            item = list_widget.currentItem()
            if item:
                h = item.data(Qt.UserRole)
                self.new_tab(h["url"], h["title"])
                dlg.accept()

        open_btn.clicked.connect(open_history)
        close_btn.clicked.connect(dlg.accept)
        btn_layout.addWidget(open_btn)
        btn_layout.addWidget(close_btn)
        layout.addLayout(btn_layout)
        dlg.setLayout(layout)
        dlg.exec_()

    def clear_history(self):
        self.history_data = []
        DataManager.save_json(HISTORY_FILE, self.history_data)
        QMessageBox.information(self, "History", "History cleared.")

    # -------------------- Settings --------------------
    def open_settings_tab(self):
        self.new_tab(SETTINGS_URL, "Settings")

    # -------------------- Close Event --------------------
    def closeEvent(self, event: QCloseEvent):
        if self.config.get("clear_history_on_close", False):
            self.clear_history()
        event.accept()

# -------------------- Entry Point --------------------
if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setApplicationName("crazy_browser")
    main_window = CrazyBrowser(is_private=False)
    main_window.show()
    sys.exit(app.exec_())
