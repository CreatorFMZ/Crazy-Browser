# crazy_browser-2.1.py
# 一个用 Python + PyQt6 写的浏览器
# 最后更新：包含设置面板（主题切换、是否保留历史、清除历史）

import sys
from PyQt6.QtWidgets import (
    QApplication,
    QMainWindow,
    QLineEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
    QToolBar,
    QTabWidget,
    QLabel,
    QProgressBar,
    QComboBox,
    QMessageBox,
    QDialog,
    QFormLayout,
    QRadioButton,
    QDialogButtonBox,
    QGroupBox,
    QCheckBox
)
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebEngineCore import QWebEngineProfile, QWebEnginePage
from PyQt6.QtCore import QUrl
from PyQt6.QtGui import QAction


class BrowserTab(QWebEngineView):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.loadProgress.connect(
            self.parent().update_progress
            if hasattr(self.parent(), 'update_progress')
            else lambda x: None
        )


class SettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("设置")
        self.setFixedSize(380, 280)

        layout = QFormLayout()

        # 主题
        theme_group = QGroupBox("主题")
        theme_layout = QVBoxLayout()
        self.light_radio = QRadioButton("浅色模式")
        self.dark_radio = QRadioButton("深色模式")
        self.light_radio.setChecked(True)
        theme_layout.addWidget(self.light_radio)
        theme_layout.addWidget(self.dark_radio)
        theme_group.setLayout(theme_layout)
        layout.addRow(theme_group)

        # 隐私
        privacy_group = QGroupBox("隐私与数据")
        privacy_layout = QVBoxLayout()
        self.persist_check = QCheckBox("保留登录状态与历史记录（重启后仍有效）")
        self.persist_check.setChecked(True)
        privacy_layout.addWidget(self.persist_check)

        clear_btn = QPushButton("立即清除所有历史记录")
        clear_btn.clicked.connect(self.clear_history_clicked)
        privacy_layout.addWidget(clear_btn)

        privacy_group.setLayout(privacy_layout)
        layout.addRow(privacy_group)

        # 确定 / 取消
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)

        self.setLayout(layout)

    def clear_history_clicked(self):
        reply = QMessageBox.question(
            self, "确认清除",
            "确定要清除所有 cookies、缓存、历史记录吗？\n此操作无法撤销。",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            profile = QWebEngineProfile.defaultProfile()
            profile.clearHttpCache()
            profile.clearAllVisitedLinks()
            profile.cookieStore().deleteAllCookies()
            QMessageBox.information(self, "已清除", "历史记录已清除完成")
            if hasattr(self.parent(), 'refresh_all_tabs'):
                self.parent().refresh_all_tabs()


class CrazyBrowser(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Crazy Browser © Fantastic Star 2026")
        self.resize(1280, 860)

        # 使用默认 profile（后续可改为持久化）
        self.profile = QWebEngineProfile.defaultProfile()

        # 主界面组件
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.currentChanged.connect(self.update_ui_from_current_tab)

        self.url_bar = QLineEdit()
        self.url_bar.returnPressed.connect(self.navigate_to_url)

        self.progress_bar = QProgressBar()
        self.progress_bar.setMaximum(100)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setFixedHeight(3)
        self.progress_bar.setStyleSheet("QProgressBar::chunk { background: #4CAF50; }")

        self.ua_combo = QComboBox()
        self.ua_combo.addItems(["桌面 (默认)", "iPhone", "Android"])
        self.ua_combo.currentIndexChanged.connect(self.change_user_agent)

        self.home_url = "https://www.google.com"

        # 工具栏
        navbar = QToolBar("导航")
        navbar.setMovable(False)
        self.addToolBar(navbar)

        navbar.addAction(QAction("←", self, triggered=self.go_back))
        navbar.addAction(QAction("→", self, triggered=self.go_forward))
        navbar.addAction(QAction("↻", self, triggered=self.reload_page))
        navbar.addAction(QAction("🏠", self, triggered=self.go_home))

        navbar.addWidget(self.url_bar)

        navbar.addWidget(QLabel(" UA: "))
        navbar.addWidget(self.ua_combo)

        new_tab_btn = QPushButton("+")
        new_tab_btn.setFixedWidth(36)
        new_tab_btn.clicked.connect(self.add_new_tab)
        navbar.addWidget(new_tab_btn)

        settings_btn = QPushButton("⚙ 设置")
        settings_btn.setFixedWidth(80)
        settings_btn.clicked.connect(self.show_settings)
        navbar.addWidget(settings_btn)

        # 整体布局
        central = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self.progress_bar)
        layout.addWidget(self.tabs)
        central.setLayout(layout)
        self.setCentralWidget(central)

        # 打开第一个标签页
        self.add_new_tab(self.home_url, "首页")

    def add_new_tab(self, url=None, title="新标签页"):
        if url is None:
            url = self.home_url

        page = QWebEnginePage(self.profile, self)
        view = BrowserTab(self)
        view.setPage(page)
        view.setUrl(QUrl(url))

        view.titleChanged.connect(
            lambda t: self.tabs.setTabText(self.tabs.indexOf(view), (t or "无标题")[:45])
        )
        view.iconChanged.connect(
            lambda icon: self.tabs.setTabIcon(self.tabs.indexOf(view), icon)
        )
        view.urlChanged.connect(self.sync_url_bar)
        view.loadStarted.connect(lambda: self.progress_bar.setValue(0))
        view.loadFinished.connect(lambda ok: self.progress_bar.setValue(100 if ok else 0))

        index = self.tabs.addTab(view, title)
        self.tabs.setCurrentIndex(index)

    def close_tab(self, index):
        if self.tabs.count() > 1:
            widget = self.tabs.widget(index)
            self.tabs.removeTab(index)
            widget.deleteLater()

    def current_view(self):
        return self.tabs.currentWidget()

    def go_back(self):
        v = self.current_view()
        if v:
            v.back()

    def go_forward(self):
        v = self.current_view()
        if v:
            v.forward()

    def reload_page(self):
        v = self.current_view()
        if v:
            v.reload()

    def go_home(self):
        v = self.current_view()
        if v:
            v.setUrl(QUrl(self.home_url))

    def navigate_to_url(self):
        text = self.url_bar.text().strip()
        if not text:
            return
        if not text.startswith(("http://", "https://")):
            text = "https://" + text
        v = self.current_view()
        if v:
            v.setUrl(QUrl(text))

    def sync_url_bar(self, qurl):
        if self.tabs.currentWidget() == self.sender():
            self.url_bar.setText(qurl.toString())
            self.url_bar.setCursorPosition(0)

    def update_ui_from_current_tab(self, index):
        if index < 0:
            return
        v = self.tabs.widget(index)
        if v:
            self.url_bar.setText(v.url().toString())

    def update_progress(self, value):
        self.progress_bar.setValue(value)

    def change_user_agent(self, index):
        ua = ""
        if index == 1:    # iPhone
            ua = "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1"
        elif index == 2:  # Android
            ua = "Mozilla/5.0 (Linux; Android 12; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36"

        self.profile.setHttpUserAgent(ua)

        # 重新加载所有有内容的标签页
        for i in range(self.tabs.count()):
            v = self.tabs.widget(i)
            if v and v.url().toString():
                v.reload()

    def show_settings(self):
        dialog = SettingsDialog(self)
        # 当前状态反映到界面（这里简单判断，实际可从配置文件读取）
        dialog.light_radio.setChecked(True)   # 默认浅色，可改逻辑
        dialog.dark_radio.setChecked(False)
        dialog.persist_check.setChecked(True)

        if dialog.exec() == QDialog.DialogCode.Accepted:
            if dialog.dark_radio.isChecked():
                self.apply_dark_theme()
            else:
                self.apply_light_theme()

            # 持久化设置提示（真正实现需在启动时创建 profile）
            if dialog.persist_check.isChecked() != True:  # 这里只是示例
                QMessageBox.information(
                    self, "提示",
                    "持久化设置更改需重启浏览器生效\n（当前版本仅提示）"
                )

    def apply_dark_theme(self):
        self.setStyleSheet("""
            QMainWindow, QWidget {
                background: #1e1e1e;
                color: #e0e0e0;
            }
            QToolBar {
                background: #252525;
                border: none;
            }
            QLineEdit {
                background: #333;
                color: #eee;
                border: 1px solid #555;
                padding: 4px;
            }
            QTabWidget::pane {
                border: 1px solid #444;
                background: #222;
            }
            QProgressBar {
                background: #333;
                border: none;
            }
            QPushButton {
                background: #444;
                color: #eee;
                border: 1px solid #555;
            }
        """)

    def apply_light_theme(self):
        self.setStyleSheet("")

    def refresh_all_tabs(self):
        for i in range(self.tabs.count()):
            v = self.tabs.widget(i)
            if v and v.url().toString():
                v.reload()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = CrazyBrowser()
    window.show()
    sys.exit(app.exec())