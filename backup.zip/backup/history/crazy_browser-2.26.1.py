import sys
from PyQt5.QtCore import QUrl
from PyQt5.QtWidgets import QApplication, QMainWindow, QToolBar, QLineEdit, QPushButton
from PyQt5.QtWebEngineWidgets import QWebEngineView

class CrazyBrowser(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('crazy_browser')
        self.setGeometry(100, 100, 1024, 768)

        # 中央浏览器组件
        self.browser = QWebEngineView()
        self.setCentralWidget(self.browser)

        # 导航工具栏
        nav_bar = QToolBar()
        self.addToolBar(nav_bar)

        # 后退按钮
        back_btn = QPushButton('←')
        back_btn.clicked.connect(self.browser.back)
        nav_bar.addWidget(back_btn)

        # 前进按钮
        forward_btn = QPushButton('→')
        forward_btn.clicked.connect(self.browser.forward)
        nav_bar.addWidget(forward_btn)

        # 刷新按钮
        refresh_btn = QPushButton('⟳')
        refresh_btn.clicked.connect(self.browser.reload)
        nav_bar.addWidget(refresh_btn)

        # 地址栏（回车加载）
        self.url_bar = QLineEdit()
        self.url_bar.returnPressed.connect(self.navigate_to_url)
        nav_bar.addWidget(self.url_bar)

        # 跳转按钮
        go_btn = QPushButton('Go')
        go_btn.clicked.connect(self.navigate_to_url)
        nav_bar.addWidget(go_btn)

        # 默认加载 Google
        self.browser.setUrl(QUrl('https://www.google.com'))

    def navigate_to_url(self):
        """地址栏输入后加载页面（自动补全 http）"""
        url = self.url_bar.text()
        if not url.startswith(('http://', 'https://')):
            url = 'http://' + url
        self.browser.setUrl(QUrl(url))


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = CrazyBrowser()
    window.show()
    sys.exit(app.exec_())